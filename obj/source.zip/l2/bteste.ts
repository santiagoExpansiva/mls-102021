/// <mls shortName="bteste" project="102021" enhancement="_100554_enhancementLit" />


import { IAteste } from '/_102021_/l2/ateste.js';
import { customElement } from 'lit/decorators.js';

@customElement('bteste-102021')
export class Bteste extends IAteste{


}