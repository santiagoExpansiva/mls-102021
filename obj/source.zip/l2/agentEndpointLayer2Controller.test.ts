/// <mls fileReference="_102021_/l2/agentEndpointLayer2Controller.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];