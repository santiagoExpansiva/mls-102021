declare module "_102021_/l2/agentEndpoint.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpoint" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
}
declare module "_102021_/l2/agentEndpointCommonLocal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointCommonLocal" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointGlobal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointGlobal" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointHelper.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointHelper" {
    export function addFile(context: mls.msg.ExecutionContext, updStatus?: boolean): Promise<void>;
}
declare module "_102021_/l2/agentEndpointLayer1Context.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer1Context" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer1localDB.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer1localDB" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer2Controller.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer2Controller" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer2Routes.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer2Routes" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer3UseCase.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer3UseCase" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer4Entity.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer4Entity" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer4EntityBase.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer4EntityBase" {
    import { IAgent } from './_100554_aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/aiIntegrationHub.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/aiIntegrationHub" {
    export function addOrUpdateEndPoint(action: string, intent: string, interfaceRequest: string, interfaceResponse: string, mock: string | undefined): Promise<any>;
}
declare module "_102021_/l2/ateste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/ateste" {
    export class IAteste extends HTMLElement {
    }
}
declare module "_102021_/l2/bteste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/bteste" {
    import { IAteste } from '/_102021_ateste';
    export class Bteste extends IAteste {
    }
}
declare module "_102021_/l2/buildServer.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/buildServer" {
    export const DISTFOLDER = "wwwroot";
    export function build(info: InfoBuild): Promise<string>;
    export function loadEsbuild(): Promise<void>;
    export interface InfoBuild {
        project: number;
        shortName: string;
        folder: string;
    }
}
declare module "_102021_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102021_/l2/liveServer.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/liveServer" {
    import { CollabLitElement } from './_100554_collabLitElement';
    import { IServer } from './_102021_start';
    export class ServicePreviewL1ListServer extends CollabLitElement {
        listItens: IServer[];
        viewServer: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IServer, idx: number): any;
        private init;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
    }
}
declare module "_102021_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/project" {
    export const projectConfig: {
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: {
            pathServer: string;
            name: string;
            path: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102021_/l2/start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/start" {
    export let servers: Record<string, IServer>;
    export let listItens: IListItem[];
    export function start(project: number, startServers?: 'all' | 'none' | string): Promise<void>;
    export function setHtml(server: IServer): Promise<void>;
    export function onServer(server: IServer): void;
    export function restartServer(server: IServer): void;
    export function offServer(server: IServer): void;
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
    export interface IServer {
        icon: string | undefined;
        name: string;
        server: string;
        iframe: HTMLIFrameElement;
        status: 'on' | 'off' | 'restarting';
    }
}
declare module "_102021_/l2/testUser.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/testUser" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Test {
        constructor();
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
    export class TestUser extends StateLitElement {
        private fire;
        users: any[];
        audit: any[];
        private iptFilter;
        form: {
            id: any;
            name: string;
            password: string;
            cpf: string;
        };
        connectedCallback(): Promise<void>;
        render(): any;
        loadUsers(filter?: string): Promise<void>;
        saveUser(user: any): Promise<void>;
        deleteUser(id: any): Promise<void>;
        loadAudit(): Promise<void>;
        selectUser(u: any): void;
        onSave(): Promise<void>;
        resetForm(): void;
        onDelete(id: any): Promise<void>;
        updateField(field: any, value: any): void;
    }
}
declare module "_102021_/l2/testeAgent.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/testeAgent" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class ExampleCqrs extends StateLitElement {
        render(): any;
        clickMsg(): void;
        addMessageIA(prompt: any, pt1: any): Promise<void>;
    }
}
declare module "_102021_/l2/example/module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/example/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: any[];
    };
}
