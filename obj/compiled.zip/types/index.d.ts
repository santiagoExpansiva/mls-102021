declare module "_102021_/l1/layer_4_entities/user" {
    export interface UserRecord {
        id?: number;
        details: UserDetails;
        version?: string;
    }
    export interface UserDetails {
        name: string;
        password: string;
        cpf: string;
    }
    export interface UserIndexRecord {
        fullText: string;
        id: number;
    }
}
declare module "_102021_/l1/global" {
    import { UserRecord } from "_102021_/l1/layer_4_entities/user";
    export * from "_102021_/l1/layer_4_entities/user";
    export interface RequestBase {
        action: ActionTypes;
        params?: Record<string, any>;
        version: string;
        inDeveloped: boolean;
    }
    export interface ResponseBase {
        statusCode: number;
        ok: boolean;
        data?: any;
        error?: string;
    }
    type ActionTypes = 'addUser' | 'uppUser' | 'delUser' | 'listUser' | 'listAudit';
    export interface RequestUserAdd extends RequestBase {
        action: 'addUser';
        params: UserRecord;
    }
    export interface RequestUserUpd extends RequestBase {
        action: 'uppUser';
        params: UserRecord;
    }
    export interface RequestUserDelById extends RequestBase {
        action: 'delUser';
        params: {
            id: number;
        };
    }
    export interface RequestUserGetList extends RequestBase {
        action: 'listUser';
        params: {
            filter: string;
        };
    }
    export interface RequestAuditList extends RequestBase {
        action: 'listAudit';
        params: {
            filter: string;
        };
    }
}
declare module "_102021_/l1/layer_4_entities/userBase" {
    import { UserRecord, UserIndexRecord } from "_102021_/l1/layer_4_entities/user";
    export interface UserBase {
        upd: (param: UserRecord) => Promise<UserRecord>;
        add: (param: UserRecord) => Promise<UserRecord>;
        del: (id: number) => Promise<boolean>;
        list: () => Promise<UserRecord[]>;
    }
    export interface UserIndexBase {
        upd: (param: UserIndexRecord) => Promise<UserIndexRecord>;
        add: (param: UserIndexRecord) => Promise<UserIndexRecord>;
        del: (id: number) => Promise<boolean>;
        list: (param: string) => Promise<UserIndexRecord[]>;
    }
}
declare module "_102021_/l1/layer_4_entities/audit" {
    export interface AuditRecord {
        id?: number;
        user: string;
        date: string;
        action: 'add' | 'update' | 'delete';
        origin: string;
        description: string;
    }
}
declare module "_102021_/l1/layer_4_entities/auditBase" {
    import { AuditRecord } from "_102021_/l1/layer_4_entities/audit";
    export interface AuditBase {
        add: (param: AuditRecord) => Promise<AuditRecord>;
        list: () => Promise<AuditRecord[]>;
    }
}
declare module "_102021_/l1/common/local" {
    import { UserBase, UserIndexBase } from "_102021_/l1/layer_4_entities/userBase";
    import { AuditBase } from "_102021_/l1/layer_4_entities/auditBase";
    export interface Ctx {
        io: {
            local: {
                user: UserBase;
                audit: AuditBase;
            };
            dynamoDb: {
                user: UserIndexBase;
            };
        };
    }
}
declare module "_102021_/l1/layer_1_external/dynamoDB/user" {
    import { UserIndexRecord } from "_102021_/l1/layer_4_entities/user";
    class User {
        upd(param: UserIndexRecord): Promise<UserIndexRecord>;
        add(param: UserIndexRecord): Promise<UserIndexRecord>;
        del(id: number): Promise<boolean>;
        list(param: string): Promise<UserIndexRecord[]>;
        private getTable;
        private setTable;
        private saveUserIndexRecord;
        private getAllUserIndexRecord;
        private deleteUserIndexRecord;
        private getNextId;
    }
    export const userDynamoDB: User;
}
declare module "_102021_/l1/layer_1_external/localDB/user" {
    import { UserBase } from "_102021_/l1/layer_4_entities/userBase";
    import { UserRecord } from "_102021_/l1/layer_4_entities/user";
    class User implements UserBase {
        upd(param: UserRecord): Promise<UserRecord>;
        add(param: UserRecord): Promise<UserRecord>;
        del(id: number): Promise<boolean>;
        list(): Promise<UserRecord[]>;
        private getTable;
        private setTable;
        private saveUserRecord;
        private getAllUserRecord;
        private deleteUserRecord;
        private getNextId;
    }
    export const userLocalDB: User;
}
declare module "_102021_/l1/layer_1_external/localDB/audit" {
    import { AuditBase } from "_102021_/l1/layer_4_entities/auditBase";
    import { AuditRecord } from "_102021_/l1/layer_4_entities/audit";
    class Audit implements AuditBase {
        add(param: AuditRecord): Promise<AuditRecord>;
        list(): Promise<AuditRecord[]>;
        private getTable;
        private setTable;
        private saveAuditRecord;
        private getAllAuditRecord;
        private getNextId;
    }
    export const auditLocalDB: Audit;
}
declare module "_102021_/l1/layer_1_external/context" {
    import { Ctx } from "_102021_/l1/common/local";
    import { RequestBase } from "_102021_/l1/global";
    export function createContext(param: RequestBase): Ctx;
}
declare module "_102021_/l1/layer_3_use_cases/addUser" {
    import { UserRecord } from "_102021_/l1/layer_4_entities/user";
    import { Ctx } from "_102021_/l1/common/local";
    export function addUser(ctx: Ctx, data: UserRecord): Promise<UserRecord>;
}
declare module "_102021_/l1/layer_2_controllers/addUser" {
    import { Ctx } from "_102021_/l1/common/local";
    import { ResponseBase } from "_102021_/l1/global";
    export function addUser(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_3_use_cases/uppUser" {
    import { UserRecord } from "_102021_/l1/layer_4_entities/user";
    import { Ctx } from "_102021_/l1/common/local";
    export function uppUser(ctx: Ctx, data: UserRecord): Promise<UserRecord>;
}
declare module "_102021_/l1/layer_2_controllers/uppUser" {
    import { Ctx } from "_102021_/l1/common/local";
    import { ResponseBase } from "_102021_/l1/global";
    export function uppUser(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_3_use_cases/delUser" {
    import { Ctx } from "_102021_/l1/common/local";
    export function delUser(ctx: Ctx, id: number): Promise<boolean | null>;
}
declare module "_102021_/l1/layer_2_controllers/delUser" {
    import { Ctx } from "_102021_/l1/common/local";
    import { ResponseBase } from "_102021_/l1/global";
    export function delUser(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_3_use_cases/listUser" {
    import { UserRecord } from "_102021_/l1/layer_4_entities/user";
    import { Ctx } from "_102021_/l1/common/local";
    export function listUser(ctx: Ctx, param: string): Promise<UserRecord[]>;
}
declare module "_102021_/l1/layer_2_controllers/listUser" {
    import { Ctx } from "_102021_/l1/common/local";
    import { ResponseBase } from "_102021_/l1/global";
    export function listUser(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_3_use_cases/listAudit" {
    import { AuditRecord } from "_102021_/l1/layer_4_entities/audit";
    import { Ctx } from "_102021_/l1/common/local";
    export function listAudit(ctx: Ctx): Promise<AuditRecord[]>;
}
declare module "_102021_/l1/layer_2_controllers/listAudit" {
    import { Ctx } from "_102021_/l1/common/local";
    import { ResponseBase } from "_102021_/l1/global";
    export function listAudit(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_2_controllers/routes" {
    import { RequestBase, ResponseBase } from "_102021_/l1/global";
    import { Ctx } from "_102021_/l1/common/local";
    export function exec(ctx: Ctx, param: RequestBase): Promise<ResponseBase>;
}
declare module "_102021_/l1/layer_1_external/index" {
    import { RequestBase, ResponseBase } from "_102021_/l1/global";
    export function exec(param: RequestBase): Promise<ResponseBase>;
    export function teste(): void;
}
declare module "_102021_/l1/layer_2_controllers/routes.defs" {
    export const routesDefinition: {
        endpoint: string;
        description: string;
        entity: string;
        file: string;
    }[];
}
declare module "_102021_/l2/agentEndpoint.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpoint" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
}
declare module "_102021_/l2/agentEndpointCommonLocal.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointCommonLocal" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointGlobal.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointGlobal" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointHelper.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointHelper" {
    export function addFile(context: mls.msg.ExecutionContext, updStatus?: boolean): Promise<void>;
}
declare module "_102021_/l2/agentEndpointLayer1Context.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer1Context" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer1localDB.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer1localDB" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer2Controller.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer2Controller" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer2Routes.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer2Routes" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer3UseCase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer3UseCase" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer4Entity.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer4Entity" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/agentEndpointLayer4EntityBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/agentEndpointLayer4EntityBase" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function lowercaseFirstLetter(text: string): string;
}
declare module "_102021_/l2/aiIntegrationHub.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/aiIntegrationHub" {
    export function addOrUpdateEndPoint(action: string, intent: string, interfaceRequest: string, interfaceResponse: string, mock: string | undefined): Promise<any>;
}
declare module "_102021_/l2/ateste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/ateste" {
    export class IAteste extends HTMLElement {
    }
}
declare module "_102021_/l2/bteste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/bteste" {
    import { IAteste } from '_102021_/l2/ateste';
    export class Bteste extends IAteste {
    }
}
declare module "_102021_/l2/buildServer.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/buildServer" {
    export const DISTFOLDER = "wwwroot";
    export function build(info: InfoBuild): Promise<string>;
    export function loadEsbuild(): Promise<void>;
    export interface InfoBuild {
        project: number;
        shortName: string;
        folder: string;
    }
}
declare module "_102021_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102021_/l2/liveServer.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/liveServer" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    import { IServer } from '_102021_/l2/start';
    export class ServicePreviewL1ListServer extends CollabLitElement {
        listItens: IServer[];
        viewServer: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IServer, idx: number): any;
        private init;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
    }
}
declare module "_102021_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/project" {
    export const projectConfig: {
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: {
            pathServer: string;
            name: string;
            path: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102021_/l2/start.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/start" {
    export let servers: Record<string, IServer>;
    export let listItens: IListItem[];
    export function start(project: number, startServers?: 'all' | 'none' | string): Promise<void>;
    export function setHtml(server: IServer): Promise<void>;
    export function onServer(server: IServer): void;
    export function restartServer(server: IServer): void;
    export function offServer(server: IServer): void;
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
    export interface IServer {
        icon: string | undefined;
        name: string;
        server: string;
        iframe: HTMLIFrameElement;
        status: 'on' | 'off' | 'restarting';
    }
}
declare module "_102021_/l2/testUser.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/testUser" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Test {
        constructor();
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
    export class TestUser extends StateLitElement {
        private fire;
        users: any[];
        audit: any[];
        private iptFilter;
        form: {
            id: any;
            name: string;
            password: string;
            cpf: string;
        };
        connectedCallback(): Promise<void>;
        render(): any;
        loadUsers(filter?: string): Promise<void>;
        saveUser(user: any): Promise<void>;
        deleteUser(id: any): Promise<void>;
        loadAudit(): Promise<void>;
        selectUser(u: any): void;
        onSave(): Promise<void>;
        resetForm(): void;
        onDelete(id: any): Promise<void>;
        updateField(field: any, value: any): void;
    }
}
declare module "_102021_/l2/testeAgent.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/testeAgent" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class ExampleCqrs extends StateLitElement {
        render(): any;
        clickMsg(): void;
        addMessageIA(prompt: any, pt1: any): Promise<void>;
    }
}
declare module "_102021_/l2/example/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_/l2/example/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: any[];
    };
}
