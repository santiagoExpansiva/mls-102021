declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102027_/l2/agentMaterializeSolution/artifactsMaterialize" {
    export interface PipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath: string;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        afterSaveBackEnd?: string;
        afterSaveFrontEnd?: string;
        visualStyle?: Record<string, unknown>;
        rulesPath?: string;
        rulesApplied?: string[];
        agent: string;
    }
    export interface AfterSaveCtx {
        type: string;
        project: number;
        moduleName: string;
        code: string;
        outputPath: string;
        shortName: string;
    }
    export type AfterSaveCallback = (ctx: AfterSaveCtx) => Promise<void>;
    export type L1LayerFolder = 'layer_1_external' | 'layer_4_entities' | 'layer_3_usecases' | 'layer_2_controllers';
    export type L1FileType = 'layer1' | 'layer4' | 'layer3' | 'layer2' | 'rulesApplied';
    export interface ScannedDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        moduleName: string;
        mlsPath: string;
    }
    export type L2FileType = 'contract' | 'shared' | 'page';
    export interface GenStepArgs {
        planId: string;
        defPath: string;
    }
    export interface ParsedMlsPath {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export interface VisualStyle {
        tone?: string;
        layout?: string;
        palette?: string[];
    }
    export interface ProjectModuleRef {
        moduleName: string;
        module?: {
            visualStyle?: VisualStyle;
        };
    }
    export interface LayoutEntry {
        name: string;
        skill: string;
    }
    export interface DesignSystemEntry {
        name: string;
        skill: string;
    }
    export interface ProjectJson {
        modules: ProjectModuleRef[];
        layouts?: Record<string, LayoutEntry>;
        designSystems?: Record<string, DesignSystemEntry>;
    }
    /** _102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs.ts */
    export function toMlsPath(project: number, level: number, folder: string, shortName: string, extension: string): string;
    export function readProjectJson(): Promise<ProjectJson | null>;
    export function scanL1DefsFiles(project: number, moduleName: string): ScannedDefsFile[];
    export function scanL1DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    export function scanL2PageDefsFiles(project: number, moduleName: string): ScannedDefsFile[];
    export function listDepLayerPaths(project: number, moduleName: string, forLayer: L1LayerFolder): string[];
    export function getFileContent(project: number, level: number, folder: string, shortName: string, extension: string): Promise<string | null>;
    export function appendPipelineToFile(project: number, level: number, folder: string, shortName: string, items: PipelineItem[]): Promise<boolean>;
    export function createDefsFile(project: number, level: number, folder: string, shortName: string, definitionJson: unknown, items: PipelineItem[]): Promise<boolean>;
    export function getEsbuild(): Promise<any>;
    export function loadModuleByBuild(path: string): Promise<any>;
    /** Extract the `pipeline` array from a .defs.ts content string. */
    export function parsePipelineFromContent(content: string): PipelineItem[] | null;
    /** Extract the `definition` template literal value from a .defs.ts content string. */
    export function parseDefinitionFromContent(content: string): string;
    /**
     * Returns the updatedAt timestamp (ms) of a file, or a sentinel, or null.
     *
     * null              → file does not exist → needs generation
     * Number.MAX_SAFE_INTEGER → file exists, no timestamp, status 'new'|'changed'
     *                       → treat as very recent, DO NOT regenerate
     * null (second case) → file exists, no timestamp, other status
     *                       → cannot determine staleness, treat as missing → regenerate
     * >0                → normal timestamp comparison
     */
    export function getFileModified(project: number, level: number, folder: string, shortName: string, extension: string): number | null;
    /** Read any file by its full MLS path string. */
    export function getContentByMlsPath(mlsPath: string): Promise<string | null>;
    /** Parse a MLS path like `_102043_/l2/cafeFlow/web/contracts/page.defs.ts`. */
    export function parseMlsPath(mlsPath: string): ParsedMlsPath | null;
    /**
     * Scan all l2 .defs.ts in sub-folders of a module that contain a pipeline export.
     * Excludes top-level source files (folder === moduleName).
     */
    export function scanL2DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        project: number;
        level: number;
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    /** Save (create or overwrite) a generated .ts file and force a recompile. */
    export function saveGeneratedTs(project: number, level: number, folder: string, shortName: string, content: string): Promise<boolean>;
    /**
     * Load rules.defs.ts for a module, filter by ruleIds and return the matched rule objects.
     * File: _<project>_/l5/<moduleName>/rules.defs.ts — exports `rulesPlan` with `data.rules[]`.
     */
    export function loadRulesForIds(project: number, moduleName: string, ruleIds: string[], rulesPath?: string): Promise<Record<string, unknown>[]>;
    /** Extract all unique string values from every JSON array field named `fieldName` in `content`. */
    export function extractJsonArrayField(content: string, fieldName: string): string[];
    export function saveGeneratedJson(project: number, level: number, folder: string, shortName: string, content: string): Promise<boolean>;
    export function saveGeneratedHtml(project: number, level: number, folder: string, shortName: string, content: string): Promise<boolean>;
    /**
     * Returns the first-level import paths from compilerResults.imports for a .ts file,
     * filtered to imports belonging to the same project.
     */
    export function getFileImports(project: number, level: number, folder: string, shortName: string): string[];
    /** Compile a generated .ts file and return any compiler errors. */
    export function compileAndGetErrors(project: number, level: number, folder: string, shortName: string): Promise<string[]>;
    /**
     * Returns the .d.ts declaration for a .ts file.
     * Tries prodDTS from the editor model (compiling on demand if needed).
     * Falls back to raw .ts content if no model is available or compile fails.
     */
    export function getDtsForFile(project: number, level: number, folder: string, shortName: string): Promise<string>;
    export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null;
}
declare module "_102021_/l2/agentMaterializeSolution/agentMaterializeL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeSolution/agentMaterializeL1Def" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeSolution/agentMaterializeMock" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export interface MockStepArgs {
        project: number;
        moduleName: string;
    }
}
declare module "_102021_/l2/agentMaterializeSolution/templateMaterialize" {
    export function buildModuleTs(project: number, moduleName: string): string;
    export function buildIndexTs(project: number, moduleName: string): string;
    export function buildRouterTs(project: number, moduleName: string): string;
    export function buildPersistenceTs(project: number, moduleName: string): string;
    export function buildConfig(project: number, moduleName: string): string;
}
declare module "_102021_/l2/agentMaterializeSolution/agentPrepareDefsL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export interface L1StepArgs {
        planId: string;
        moduleName: string;
        shortName: string;
        layerFolder: string;
    }
}
declare module "_102021_/l2/agentMaterializeSolution/ast/astRouter" {
    export interface ImportEntry {
        /** 'import type' or 'import' */
        kind: 'type' | 'value';
        /** named imports */
        names: string[];
        /** caminho do módulo */
        from: string;
    }
    export interface RouteEntry {
        /** chave do Map: 'pizzaria.getCustomer' */
        key: string;
        /** nome do handler: 'customerEditorGetCustomerHandler' */
        handler: string;
    }
    export function parseRouter(source: string): {
        mlsComment: string | null;
        imports: ImportEntry[];
        routes: RouteEntry[];
    };
    export function getMlsComment(source: string): string | null;
    export function getImports(source: string): ImportEntry[];
    export function hasImport(source: string, from: string): boolean;
    /**
     * Adiciona um import.
     * - Se já existe um import do mesmo `from`, faz merge dos `names`.
     * - Caso contrário, insere antes da primeira linha `export`.
     */
    export function addImport(source: string, imp: ImportEntry): string;
    /**
     * Remove o import inteiro cujo `from` bate com o argumento.
     */
    export function removeImport(source: string, from: string): string;
    /**
     * Remove um nome específico de um import.
     * Se for o único nome, remove o import inteiro.
     */
    export function removeImportName(source: string, from: string, name: string): string;
    export function getRoutes(source: string): RouteEntry[];
    export function hasRoute(source: string, key: string): boolean;
    /**
     * Adiciona uma rota ao Map, depois da última entrada existente.
     * Suporta Map vazio: new Map([]) ou new Map<...>([]).
     *
     * @param throwIfExists - se true, lança erro quando a rota já existe. Default: false.
     */
    export function addRoute(source: string, key: string, handler: string, throwIfExists?: boolean): string;
    /**
     * Remove uma rota do Map pela chave.
     */
    export function removeRoute(source: string, key: string): string;
    /**
     * Troca o handler de uma rota existente (substituição por posição).
     */
    export function updateRoute(source: string, key: string, newHandler: string): string;
    type RouteHandlerPair = [routeKey: string, handlerName: string];
    export function extractRouteHandlers(definition: {
        pages: any[];
    }, moduleName: string): RouteHandlerPair[];
}
declare module "_102021_/l2/agentMaterializeSolution/ast/astPersistence" {
    export interface ImportEntry {
        kind: 'type' | 'value';
        names: string[];
        from: string;
    }
    export function parsePersistence(source: string): {
        imports: ImportEntry[];
        tableDefVarNames: string[];
    };
    export function getImports(source: string): ImportEntry[];
    export function hasImport(source: string, from: string): boolean;
    export function getTableDefs(source: string): string[];
    export function hasTableDef(source: string, varName: string): boolean;
    export function addTableDef(source: string, varName: string, importPath: string, throwIfExists?: boolean): string;
    export function removeTableDef(source: string, varName: string, importPath: string): string;
    export function extractTableDefVarName(source: string): string | null;
}
declare module "_102021_/l2/agentMaterializeSolution/registerBackEnd" {
    import type { AfterSaveCtx } from "_102027_/l2/agentMaterializeSolution/artifactsMaterialize";
    export function registerController(ctx: AfterSaveCtx): Promise<void>;
    export function registerLayer1(ctx: AfterSaveCtx): Promise<void>;
}
