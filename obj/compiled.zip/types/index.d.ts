declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
