declare module "_102021_/l2/agentChangeBackend/cbMaterializeCore" {
    export interface PipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath?: string;
        dependsFiles?: string[];
        dependsOn?: string[];
        skills?: string[];
        rulesApplied?: string[];
        agent?: string;
    }
    export interface ParsedDefs {
        dataExportName: string | null;
        artifact: Record<string, unknown> | null;
        data: unknown;
        item: PipelineItem | null;
    }
    export interface PlannedItem {
        item: PipelineItem;
        rank: number;
        stale: boolean;
        reason: string;
    }
    export interface MaterializeEnv {
        readRef(ref: string): Promise<string | null>;
        modifiedMs(ref: string): Promise<number | null>;
    }
    export interface GenResult {
        code: string;
    }
    export function layerRank(type: string): number;
    export function orderItems(items: PipelineItem[]): PipelineItem[];
    export function isStale(defsMs: number | null, tsMs: number | null): boolean;
    export function parseDefs(src: string): ParsedDefs;
    export const GEN_TOOL_NAME = "submitGeneratedTs";
    export const GEN_TOOL: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitGeneratedTs";
            readonly description: "Submit the complete generated TypeScript file content.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["code"];
                readonly properties: {
                    readonly code: {
                        readonly type: "string";
                        readonly description: "Complete TypeScript file content. Must start with the /// <mls fileReference=\"...\"> header.";
                    };
                };
            };
        };
    };
    export const DEFAULT_MODEL_TYPE = "codehigh";
    export function parseModelType(systemPrompt: string): string | null;
    export function buildSystemPrompt(skillSections: string[], outputPath: string, modelType: string): string;
    export function buildHumanPrompt(data: unknown, contextSections: string[], outputPath: string): string;
    export function applyHeader(outputPath: string, code: string): string;
    export const CONTRACTS_102034: readonly string[];
    export function expandContextRef(ref: string): string[];
}
declare module "_102021_/l1/cbMaterializeCli/llmClient" {
    import { type GenResult } from "_102021_/l2/agentChangeBackend/cbMaterializeCore";
    export interface LlmConfig {
        baseUrl: string;
        token: string;
        orgId?: string;
        userId?: string;
        agentName?: string;
        toolStrict?: boolean;
        timeoutMs?: number;
        temperature?: number;
        maxTokens?: number;
    }
    export function parseGenResult(responseText: string, toolName?: string): GenResult;
    export interface LlmCallInput {
        model: string;
        system: string;
        human: string;
    }
    export interface LlmResult {
        ok: boolean;
        code?: string;
        raw: string;
        usage?: Record<string, unknown>;
        httpStatus: number;
        error?: string;
    }
    export function callCollabLlm(cfg: LlmConfig, input: LlmCallInput): Promise<LlmResult>;
}
declare module "_102021_/l1/cbMaterializeCli/nodejsMaterializeL1" { }
declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentChangeBackend/agentCbAggregateIndex" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbBffIndex" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbDomainEntity" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbFinalSummary" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbFinalizeStatus" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbHttpController" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbLockOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbPersistenceIndex" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbPersistenceTable" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbRegister" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbRepositoryAdapter" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbRepositoryPort" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbScanCreateOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbUsecase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbUsecaseIndex" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbValidateAll" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentCbValidateL4Readiness" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/agentChangeBackend" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        dsGlobalCss?: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentChangeBackend/cbMaterializeIo" {
    import type { PipelineItem } from '_102021_/l2/agentChangeBackend/cbMaterializeCore';
    export interface ParsedMlsPath {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    /** Extract the `pipeline` array from a .defs.ts content string. */
    export function parsePipelineFromContent(content: string): PipelineItem[] | null;
    /** Scan every l1 .defs.ts (with a pipeline) of a module. */
    export function scanL1DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    /** updatedAt (ms) of a file, MAX_SAFE_INTEGER when new/changed without a timestamp, else null. */
    export function getFileModified(project: number, level: number, folder: string, shortName: string, extension: string): number | null;
    /** Read any file by its full MLS path string. */
    export function getContentByMlsPath(mlsPath: string): Promise<string | null>;
    /** Parse a MLS path like `_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts`. */
    export function parseMlsPath(mlsPath: string): ParsedMlsPath | null;
    /** Save (create or overwrite) a generated .ts file and force a recompile. */
    export function saveGeneratedTs(project: number, level: number, folder: string, shortName: string, content: string): Promise<boolean>;
    /** Pull the arguments of a named tool call out of the model payload (several shapes supported). */
    export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null;
}
declare module "_102021_/l2/agentChangeBackend/cbSchemas" {
    export const aggregateIndexResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["aggregates"];
        readonly properties: {
            readonly aggregates: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const persistenceIndexResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["tables"];
        readonly properties: {
            readonly tables: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const usecaseIndexResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["usecases"];
        readonly properties: {
            readonly usecases: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const bffIndexResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["pages"];
        readonly properties: {
            readonly pages: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const domainEntityResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "fields"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly title: {
                readonly type: "string";
            };
            readonly fields: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["fieldId", "type", "required"];
                    readonly properties: {
                        readonly fieldId: {
                            readonly type: "string";
                        };
                        readonly type: {
                            readonly type: "string";
                        };
                        readonly required: {
                            readonly type: "boolean";
                        };
                        readonly description: {
                            readonly type: "string";
                        };
                        readonly enum: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
            readonly valueObjects: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly invariants: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly statusEnum: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const repositoryPortResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "interfaceName", "methods"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly interfaceName: {
                readonly type: "string";
            };
            readonly methods: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const persistenceTableResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["tableId", "tableName", "columns", "primaryKey"];
        readonly properties: {
            readonly tableId: {
                readonly type: "string";
            };
            readonly tableName: {
                readonly type: "string";
            };
            readonly columns: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly primaryKey: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly indexes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly detailsColumn: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["enabled"];
                readonly properties: {
                    readonly enabled: {
                        readonly type: "boolean";
                    };
                    readonly columnName: {
                        readonly type: "string";
                    };
                    readonly childCollections: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                };
            };
        };
    };
    export const repositoryAdapterResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "className", "portRef", "tableRef"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly className: {
                readonly type: "string";
            };
            readonly portRef: {
                readonly type: "string";
            };
            readonly tableRef: {
                readonly type: "string";
            };
            readonly mdmReads: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly notes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const usecaseResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["usecaseId", "ports", "functions"];
        readonly properties: {
            readonly usecaseId: {
                readonly type: "string";
            };
            readonly ports: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly rulesApplied: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly functions: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["functionName", "inputTypeName", "outputTypeName", "input", "output"];
                    readonly properties: {
                        readonly functionName: {
                            readonly type: "string";
                        };
                        readonly inputTypeName: {
                            readonly type: "string";
                        };
                        readonly outputTypeName: {
                            readonly type: "string";
                        };
                        readonly input: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                };
                            };
                        };
                        readonly output: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                };
                            };
                        };
                        readonly ports: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly rulesApplied: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly transactional: {
                            readonly type: "boolean";
                        };
                        readonly steps: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
    };
    export const httpControllerResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["pageId", "controllerName", "handlers", "routes"];
        readonly properties: {
            readonly pageId: {
                readonly type: "string";
            };
            readonly controllerName: {
                readonly type: "string";
            };
            readonly handlers: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly routes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const finalSummaryResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly ownersDone: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly warnings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
}
declare module "_102021_/l2/agentChangeBackend/cbShared" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, type PlannerExtractConfig, type PlannerOutput } from '_102020_/l2/agentNewSolution2/ns2Extract';
    import { saveAgentTrace } from '_102020_/l2/agentNewSolution2/ns2Artifacts';
    export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, saveAgentTrace, };
    export type { PlannerExtractConfig, PlannerOutput };
    /** Loose planner config: validates the envelope and returns the `result` object as a record. Each
     * agent reads the array property it expects (items/aggregates/tables/...). */
    export function plannerConfig(toolName: string): PlannerExtractConfig<Record<string, unknown>>;
    /** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
     * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
    export function batchSchema(itemSchema: Record<string, unknown>): Record<string, unknown>;
    export function asArray(value: unknown): Record<string, unknown>[];
    export type ExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type EntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm';
    export type CbFileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export interface CbOwner {
        kind: 'operation' | 'workflow';
        id: string;
        title: string;
        entity: string;
        opKind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        statusBackend: string;
        moduleName: string;
    }
    export interface CbEntity {
        entityId: string;
        title: string;
        kind: EntityKind;
        ownership: string;
        moduleName: string;
        fields?: Record<string, unknown>[];
    }
    export interface CbRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
    }
    export interface CbAggregate {
        aggregateId: string;
        rootEntity: string;
        embeddedMembers: string[];
        events: string[];
        mdmRefs: string[];
    }
    export interface CbScan {
        project: number;
        moduleNames: string[];
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        aggregates: CbAggregate[];
    }
    export function readBackendScan(statuses?: string[]): Promise<CbScan>;
    export function deriveAggregates(entities: CbEntity[], relationships: CbRelationship[], operatedRootIds?: Set<string>): CbAggregate[];
    export interface CbColumnPlan {
        fieldId: string;
        reason: string;
    }
    export interface CbTablePlan {
        tableId: string;
        rootEntity: string;
        ownership: string;
        indexedColumns: CbColumnPlan[];
        detailsFields: string[];
        childCollections: string[];
    }
    /** Heuristic: a field needs a real column when it is the id (PK), a reference/FK (type is an entity
     * id or ends with "Id"), a status/lifecycle field, or an ordering timestamp (createdAt). Everything
     * else goes into details JSONB. Deterministic baseline for the LLM persistence-index agent. */
    export function planTableColumns(fields: Record<string, unknown>[], knownEntityIds: Set<string>): {
        indexed: CbColumnPlan[];
        details: string[];
    };
    export function domainEntityFileInfo(m: string, entityId: string): CbFileInfo;
    export function valueObjectFileInfo(m: string, memberId: string): CbFileInfo;
    export function repositoryPortFileInfo(m: string, entityId: string): CbFileInfo;
    export function usecaseFileInfo(m: string, usecaseId: string): CbFileInfo;
    export function persistenceTableFileInfo(m: string, tableId: string): CbFileInfo;
    export function repositoryAdapterFileInfo(m: string, entityId: string): CbFileInfo;
    export function httpControllerFileInfo(m: string, pageId: string): CbFileInfo;
    export function defsRef(fileInfo: CbFileInfo): string;
    /** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
    export function dtsRef(fileInfo: CbFileInfo): string;
    /** Standard planning envelope shared by every .defs.ts data block. */
    export function buildArtifact(artifactType: string, artifactId: string, moduleName: string, agentName: string, data: unknown): Record<string, unknown>;
    /** Materialization context for a layer: the hexagonal base architecture skill + the per-type skill
     * (both co-located with this agent) + the platform defs. */
    export function layerSkills(skillFile: string): string[];
    export interface CbPipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath: string;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        rulesPath?: string;
        rulesApplied?: string[];
        agent: string;
    }
    /** Build the pipeline item that makes a .defs.ts self-sufficient for materialization (agentCbMaterialize
     * in-flow, or the cbMaterializeCli Node runner): it carries the outputPath (.ts), the dependsFiles
     * (.d.ts of the inner callee layer) and skills (the LLM context = layer skill + platform defs).
     * See spec.md (auto-suficiência). */
    export function buildPipelineItem(shortName: string, type: string, fileInfo: CbFileInfo, dependsFiles: string[], skills: string[], opts?: {
        rulesPath?: string;
        rulesApplied?: string[];
    }): CbPipelineItem;
    /** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
     * (optionally) the `export const pipeline`. Force-overwrites. */
    export function saveDefs(fileInfo: CbFileInfo, exportName: string, data: unknown, pipeline?: CbPipelineItem[]): Promise<string>;
    /** Read the owner's l4 .defs.ts, set statusBackend, and rewrite it preserving the export name. */
    export function setOwnerStatusBackend(owner: CbOwner, status: OwnerStatus): Promise<boolean>;
    export function createUpdateStatusIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg?: string, cleaner?: 'input' | 'input_output'): mls.msg.AgentIntentUpdateStatus;
    export function createAgentStepPayload(planId: string, agentName: string, stepTitle: string, args: unknown, dependsOn: string[], executionMode: ExecutionMode, status?: mls.msg.AIStepStatus, dynamicSource?: unknown): mls.msg.AIAgentStep;
    export function createAddStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep): mls.msg.AgentIntentAddStep;
    export function createPromptReadyIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, hookSequential: number, args: string, systemPrompt: string, humanPrompt: string, toolSchema: mls.msg.LLMTool, toolName: string): mls.msg.AgentIntentPromptReady;
    /** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
    export function createParallelStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args: string[], dependsOn?: string[], maxParallel?: number): mls.msg.AgentIntentAddStep;
    export function logPrefix(agent: IAgentMeta | {
        agentName: string;
    }): string;
    export function planIdOf(step: mls.msg.AIPayload | undefined): string;
    /** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
     * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
     * compile; parallelization is a later optimization. */
    export function enqueueNext(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, currentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args?: unknown): mls.msg.AgentIntentAddStep;
    export function parseDefsSource(content: string): unknown;
    export function readString(value: unknown): string;
    export function readStringArray(value: unknown): string[];
    export function lowerFirst(value: string): string;
    export function capitalize(value: string): string;
    export function toSafeShortName(value: string): string;
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
