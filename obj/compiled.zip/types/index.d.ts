declare module "_102021_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102021_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_project" {
    export const modules: {
        pathServer: string;
        name: string;
        path: string;
        auth: string;
        icon: string;
    }[];
}
