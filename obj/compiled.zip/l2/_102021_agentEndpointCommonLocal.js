/// <mls shortName="agentEndpointCommonLocal" project="102021" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { getNextInProgressStepByAgentName, notifyTaskChange, updateStepStatus, getNextPendingStepByAgentName } from "./_100554_aiAgentHelper";
import { startNewAiTask, startNewInteractionInAiTask } from "./_100554_aiAgentOrchestration";
import { addFile } from './_102021_agentEndpointHelper';
const agentName = "agentEndpointCommonLocal";
const project = 102021;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent agentEndpointCommonLocal, for create tipe context",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async installBot(context) {
            throw new Error('Not implement');
        },
        async beforeBot(context, msg, toolsBeforeSendMessage) {
            throw new Error('Not implement');
        },
        async afterBot(context, output) {
            throw new Error('Not implement');
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        let prompt = context.message.content.replace('@@agentEndpointCommonLocal', '').trim();
        const inputs = await getPrompts(prompt);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
        return;
    }
    const pageMemory = context.task?.iaCompressed?.longMemory;
    if (!pageMemory || !pageMemory.info)
        throw new Error(`[${agentName}]: Not found page memory `);
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
    context = await updateStepStatus(context, step.stepId, "in_progress");
    const data = pageMemory.info;
    const inputs = await getPrompts(data);
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    await addFile(context, true);
    notifyTaskChange(context);
};
async function getPrompts(userPrompt) {
    const info = JSON.parse(userPrompt || '{}');
    const dataForReplace = {
        userPrompt,
        source: await getContext(),
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
async function getContext() {
    const key = mls.stor.getKeyToFiles(mls.actualProject || 0, 1, 'local', 'common', '.ts');
    if (!mls.stor.files[key])
        return '';
    const txt = await mls.stor.files[key].getContent();
    return txt;
}
export function lowercaseFirstLetter(text) {
    if (!text) {
        return text;
    }
    return text.charAt(0).toLowerCase() + text.slice(1);
}
//------TESTE------
/*

{
    "endpoint": "addProduct",
    "description": "Adiciona um novo produto ao sistema",
    "entity": "Product",
    "file": "layer_2_controllers/addProduct"
}

{
    "endpoint": "addUser",
    "description": "Adiciona um novo usuário ao sistema, verificando se a senha tem pelo menos 6 caracteres",
    "entity": "User",
    "file": "layer_2_controllers/addUser"
}


 */ 
