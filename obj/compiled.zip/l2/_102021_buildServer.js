/// <mls shortName="buildServer" project="102021" enhancement="_blank" />
import { createStorFile } from './_100554_collabLibStor';
let esBuild;
export const DISTFOLDER = 'wwwroot';
export async function build(info) {
    try {
        await loadEsbuild();
        const ret = await buildServer(info);
        return ret;
    }
    catch (e) {
        console.info('[buildServer]:' + e.message);
        return '[buildServer]: Erro to build';
    }
}
export async function loadEsbuild() {
    if (mls.esbuild) {
        esBuild = mls.esbuild;
    }
    else if (!mls.esbuildInLoad)
        await initializeEsBuild();
}
async function initializeEsBuild() {
    mls.esbuildInLoad = true;
    const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
    if (!esBuild) {
        esBuild = await import(url);
        await esBuild.initialize({
            wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
        });
        mls.esbuild = esBuild;
        mls.esbuildInLoad = false;
    }
}
async function buildServer(info) {
    const key = mls.stor.getKeyToFiles(info.project, 1, info.shortName, info.folder, '.ts');
    if (!mls.stor.files[key])
        throw new Error('[buildServer]: Not found stor');
    const actualFile = mls.stor.files[key];
    let name = `/_${actualFile.project}_${actualFile.shortName}`;
    if (actualFile.folder)
        name = `/_${actualFile.project}_${actualFile.folder}/${actualFile.shortName}`;
    const ret = {
        errors: [],
        importsJs: ["/_100554_collabConsoleL1", name],
        importsMap: ['"lit": "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js"', '"lit/decorators.js": "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm"']
    };
    const bundle = await compileWithEsbuild(ret, actualFile);
    if (!bundle)
        throw new Error(`[buildServer]: Build returned empty result`);
    return bundle;
}
async function compileWithEsbuild(info, storFile) {
    try {
        if (!esBuild) {
            console.warn("[buildServer]: esbuild not loaded");
            return null;
        }
        const storDist = getDistStorFile(storFile.project);
        let needCompile = !storDist;
        const virtualFiles = await getVirtualFiles(storFile);
        let entryCode = Object.keys(mls.stor.files).map((p, i) => {
            const sf = mls.stor.files[p];
            if (!sf || sf.level !== 1 || sf.extension != '.ts' || sf.project !== storFile.project)
                return '';
            if (!needCompile || (storDist && new Date(sf.updatedAt || '') > new Date(storDist.updatedAt || '')))
                needCompile = true;
            const verify = `/_${sf.project}_${sf.folder ? sf.folder + '/' : ''}${sf.shortName}`;
            const name = './' + (sf.folder ? sf.folder + '/' : '') + sf.shortName + '.js';
            const aux = info.importsJs.includes(verify) ? `Object.assign(window, m${i});` : '';
            return `import * as m${i} from "${name}";
                ${aux} 
                `;
        }).join("\n").trim();
        if (!needCompile)
            return await storDist.getContent();
        const result = await esBuild.build({
            stdin: {
                contents: entryCode,
                sourcefile: "virtual-entry.ts",
                resolveDir: "/",
            },
            bundle: true,
            write: false,
            format: "esm",
            loader: { ".ts": "ts" },
            minify: true,
            plugins: [getVirtualFilesPlugin(virtualFiles)]
        });
        if (!result.outputFiles || !result.outputFiles[0])
            return null;
        await generateOutput(storFile.project, result.outputFiles[0].text);
        return result.outputFiles[0].text;
    }
    catch (err) {
        console.error("esbuild error:", err);
        return null;
    }
}
async function getVirtualFiles(storFile) {
    let files = {};
    for (const [name, f] of Object.entries(mls.stor.files)) {
        if (!f || f.project !== storFile.project || f.level !== 1 || f.extension !== '.ts')
            continue;
        const name = ((f.folder ? f.folder + '/' + f.shortName : f.shortName) + '.js').toLocaleLowerCase();
        if (files[name])
            continue;
        files[name] = await f.getContent();
    }
    return files;
}
function getVirtualFilesPlugin(files) {
    return {
        name: "virtual-files",
        setup(build) {
            // Resolver imports relativos
            build.onResolve({ filter: /^(\.|\/)/ }, (args) => {
                if (args.importer.split('/').length >= 3) {
                    const importer = args.importer;
                    const base = "file://" + importer;
                    const resolvedURL = new URL(args.path, base);
                    let resolved = resolvedURL.pathname;
                    // adiciona extensão se faltar
                    if (!resolved.endsWith(".ts") && !resolved.endsWith(".js")) {
                        resolved += ".js";
                    }
                    return {
                        path: resolved,
                        namespace: "vfs",
                    };
                }
                else {
                    const resolved = new URL(args.path, "file://" + args.resolveDir + "/").pathname;
                    return { path: resolved.endsWith(".ts") || resolved.endsWith(".js") ? resolved : resolved + ".js", namespace: "vfs" };
                }
            });
            // Retornar conteúdo dos arquivos da memória
            build.onLoad({ filter: /\.(ts|js)$/, namespace: "vfs" }, (args) => {
                const path = (args.path.replace(/^\/+/, "").trim()).toLocaleLowerCase(); // remove /
                const content = files[path];
                if (!content) {
                    console.warn("Arquivo não encontrado no virtual FS:", path);
                    return { contents: "", loader: "ts" };
                }
                return { contents: content, loader: "ts" };
            });
        }
    };
}
async function generateOutput(project, srcBuild) {
    const newDistFolder = `${DISTFOLDER}`;
    let storFilesDist = getDistStorFile(project);
    if (!storFilesDist)
        storFilesDist = await createStorFileOutput({ project, shortName: 'serverRunTime', folder: newDistFolder, ext: '.js' }, srcBuild);
    else
        await mls.stor.localStor.setContent(storFilesDist, { contentType: 'string', content: srcBuild });
    storFilesDist.updatedAt = new Date().toISOString();
}
function getDistStorFile(project) {
    const newDistFolder = `${DISTFOLDER}`;
    const keyToDistJs = mls.stor.getKeyToFiles(project, 1, 'serverRunTime', newDistFolder, '.js');
    let storFileDistJs = mls.stor.files[keyToDistJs];
    return storFileDistJs;
}
async function createStorFileOutput(data, source) {
    const param = {
        project: data.project,
        shortName: data.shortName,
        folder: data.folder,
        level: 1,
        extension: data.ext,
        source,
        status: 'new'
    };
    const storFile = await createStorFile(param, false, false, false);
    return storFile;
}
