/// <mls shortName="liveServer" project="102021" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, unsafeHTML } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { servers, onServer, offServer, restartServer } from './_102021_start';
let ServicePreviewL1ListServer = class ServicePreviewL1ListServer extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`live-server-102021{position:relative;display:block;margin:0;background:linear-gradient(180deg, #071022 0%, #081726 100%);color:#e6eef6;width:100%;height:100%;font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial}live-server-102021 .wrap{max-width:980px;padding:24px}live-server-102021 header{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}live-server-102021 h1{font-size:20px;margin:0;letter-spacing:.2px}live-server-102021 p.lead{margin:0;color:#9aa6b2;font-size:13px}live-server-102021 .list{display:grid;gap:12px}live-server-102021 .server{display:flex;align-items:center;gap:18px;padding:14px;border-radius:10px;background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));box-shadow:0 6px 18px rgba(2,6,23,0.6);border:1px solid rgba(255,255,255,0.03)}live-server-102021 .server-main{display:flex;align-items:center;gap:14px;flex:1;min-width:0}live-server-102021 .thumb{width:56px;height:56px;border-radius:8px;background:linear-gradient(135deg, rgba(255,255,255,0.02), rgba(0,0,0,0.12));display:flex;align-items:center;justify-content:center;font-weight:600;color:#9aa6b2;font-size:14px;border:1px solid rgba(255,255,255,0.03)}live-server-102021 .thumb svg{width:30px !important;height:30px !important;fill:white}live-server-102021 .meta{min-width:0}live-server-102021 .meta .name{font-weight:600;font-size:15px;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}live-server-102021 .meta .desc{font-size:13px;color:#9aa6b2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}live-server-102021 .status{display:flex;align-items:center;gap:10px;min-width:220px;justify-content:flex-end}live-server-102021 .badge{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;font-size:13px;font-weight:600;color:#062024}live-server-102021 .badge--on{background:linear-gradient(90deg, rgba(22,163,74,0.15), rgba(22,163,74,0.06));color:#16a34a;border:1px solid rgba(22,163,74,0.18)}live-server-102021 .badge--restart{background:linear-gradient(90deg, rgba(144,163,22,0.15), rgba(158,163,22,0.06));color:#16a34a;border:1px solid rgba(156,163,22,0.18)}live-server-102021 .badge--off{background:linear-gradient(90deg, rgba(239,68,68,0.06), rgba(239,68,68,0.02));color:#ef4444;border:1px solid rgba(239,68,68,0.12)}live-server-102021 .controls{display:flex;gap:8px;margin-left:12px}live-server-102021 button.btn{appearance:none;border:0;padding:8px 10px;border-radius:8px;font-size:13px;cursor:pointer;font-weight:600;background:rgba(255,255,255,0.03);color:#9aa6b2;transition:transform .12s ease,box-shadow .12s ease,background .12s ease;display:inline-flex;gap:8px;align-items:center}live-server-102021 button.btn:active{transform:translateY(1px) scale(.998)}live-server-102021 button.btn:focus{outline:2px solid rgba(6,182,212,0.14);box-shadow:0 4px 18px rgba(6,182,212,0.06)}live-server-102021 button.btn--primary{background:linear-gradient(90deg, rgba(6,182,212,0.12), rgba(6,182,212,0.06));color:#06b6d4;border:1px solid rgba(6,182,212,0.08)}live-server-102021 button.btn--danger{background:linear-gradient(90deg, rgba(239,68,68,0.06), rgba(239,68,68,0.02));color:#ef4444;border:1px solid rgba(239,68,68,0.06)}live-server-102021 .icon{width:14px;height:14px;display:inline-block;vertical-align:middle;opacity:.95}@media (max-width:700px){live-server-102021 .server{flex-direction:column;align-items:stretch}live-server-102021 .status{justify-content:space-between;min-width:0;margin-top:10px}live-server-102021 .controls{margin-left:0;justify-content:flex-end}}live-server-102021 .spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(255,255,255,0.08);border-top-color:rgba(255,255,255,0.28);animation:spin .9s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}live-server-102021 .modal-backdrop{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:rgba(2,6,23,0.6);z-index:40}live-server-102021 .modal-backdrop.show{display:flex}live-server-102021 .modal{width:min(720px, 92%);background:linear-gradient(180deg, #071226, #061424);border-radius:12px;padding:18px;border:1px solid rgba(255,255,255,0.03);box-shadow:0 12px 40px rgba(2,6,23,0.7)}live-server-102021 .modal iframe{width:100%;height:500px}live-server-102021 .modal h3{margin:0 0 8px 0;font-size:18px}live-server-102021 .modal p{margin:0 0 12px 0;color:#9aa6b2;font-size:13px}live-server-102021 .modal .close{float:right}`);
        this.listItens = [];
        this.init();
    }
    //--------COMPONENT----------
    render() {
        return html `
        <div class="wrap">
            ${this.renderHeader()}
            ${this.renderList()}
        </div>
        <div id="modal" class="modal-backdrop" role="dialog" aria-modal="true" aria-hidden="true">
            <div class="modal" role="document">
                <button class="btn close" id="closeModal" aria-label="Fechar" @click=${this.handleCloseView}>Close</button>
                <h3 id="modalTitle">Server Details</h3>
                <p id="modalBody">Server information...</p>
                <div id="viewServer">
                </div>
            </div>
        </div>
        `;
    }
    renderHeader() {
        return html `
        <header>
            <div>
                <h1>Servers</h1>
                <p class="lead">List of servers with status and quick actions (Power On/Off, Restart, View)</p>
            </div>
        </header>
        `;
    }
    renderList() {
        return html `
        <main>
            <div class="list" id="serverList" aria-live="polite">
                ${repeat(this.listItens, ((key) => key.server), ((k, index) => { return this.renderItem(k, index); }))}
            </div>
        </main>
        `;
    }
    renderItem(item, idx) {
        const n = item.icon ? unsafeHTML(item.icon) : `SV${idx + 1}`;
        let clsBadge = '';
        let textBadge = '';
        let disabled = false;
        let attr = '';
        if (item.status === 'on') {
            clsBadge = 'badge--on';
            textBadge = ' On';
            disabled = false;
            attr = '';
        }
        else if (item.status === 'off') {
            clsBadge = 'badge--off';
            textBadge = ' Off';
            disabled = true;
            attr = 'aria-disabled';
        }
        else if (item.status === 'restarting') {
            clsBadge = 'badge--restart';
            textBadge = '<span class="spinner" aria-hidden="true"></span> Restarting';
            disabled = true;
            attr = 'aria-disabled';
        }
        return html `
        <div class="server" data-status="off" data-path="${item.server}">
            <div class="server-main">
                <div class="thumb">${n}</div>
                <div class="meta">
                    <div class="name">${item.name}</div>
                    <div class="desc">File: ${item.server}</div>
                </div>
            </div>

            <div class="status">
                <div class="badge ${clsBadge}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.6"/></svg>
                    ${textBadge}
                </div>

                <div class="controls">
                    <button class="btn btn--primary btn-power" title="Desligar/ligar" @click=${this.handleClickPower}>
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2v6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M5.5 8.5a7 7 0 1013 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                        Power
                    </button>

                    <button class="btn btn--danger btn-restart" title="Restart"  @click=${this.handleClickRestart} ?disabled=${disabled} ${attr}>
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M21 12a9 9 0 11-9-9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        Restart
                    </button>

                    <button class="btn btn--primary btn-view" title="Visualizar" @click=${this.handleClickView} >
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
                        View
                    </button>
                </div>
            </div>
        </div>
        `;
    }
    //---------IMPLEMENTS-------------
    async init() {
        this.listItens = Object.values(servers);
    }
    handleClickPower(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        const current = server.getAttribute('data-status');
        if (current === 'on') {
            server.setAttribute('data-status', 'off');
        }
        else {
            server.setAttribute('data-status', 'on');
        }
        this.refreshRow(path, server);
    }
    handleClickRestart(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        if (server.getAttribute('data-status') !== 'on')
            return;
        server.setAttribute('data-status', 'restarting');
        this.refreshRow(path, server);
    }
    handleClickView(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        const modal = this.querySelector('#modal');
        if (!modal)
            return;
        if (!this.viewServer)
            return;
        const item = this.listItens.find((i) => i.server === path);
        if (!item)
            return;
        this.viewServer.innerHTML = '';
        this.viewServer.appendChild(item.iframe);
        modal.classList.add('show');
        modal.setAttribute('aria-hidden', 'false');
    }
    handleCloseView(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const modal = btn.closest('#modal');
        if (!modal)
            return;
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
    }
    refreshRow(path, row) {
        const status = row.getAttribute('data-status');
        const item = this.listItens.find((i) => i.server === path);
        if (!item)
            return;
        if (status === 'on') {
            item.status = 'on';
            onServer(item);
        }
        else if (status === 'off') {
            item.status = 'off';
            offServer(item);
        }
        else if (status === 'restarting') {
            item.status = 'restarting';
            restartServer(item);
        }
        this.requestUpdate();
    }
};
__decorate([
    state()
], ServicePreviewL1ListServer.prototype, "listItens", void 0);
__decorate([
    query("#viewServer")
], ServicePreviewL1ListServer.prototype, "viewServer", void 0);
ServicePreviewL1ListServer = __decorate([
    customElement('live-server-102021')
], ServicePreviewL1ListServer);
export { ServicePreviewL1ListServer };
