/// <mls fileReference="_102021_/l2/testUser.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
const pendingRequests = {};
export class Test {
    constructor() {
        this.mode = 'develpoment';
        this.running = false;
        this.open();
        this.listen();
    }
    open(name = 'collab') {
        if (this.running)
            return this;
        this.channel = new BroadcastChannel(name);
        return this;
    }
    listen(mode = 'develpoment') {
        if (this.running)
            return this;
        if (!this.channel)
            throw new Error('Channel not opened');
        this.mode = mode;
        this.channel.onmessage = (event) => {
            if (event.data.type !== "fetch-response")
                return;
            const resolve = pendingRequests[event.data.id];
            if (!resolve)
                return;
            delete pendingRequests[event.data.id];
            resolve(new Response(event.data.body, {
                status: event.data.status,
                headers: event.data.headers
            }));
        };
        this.running = true;
        return this;
    }
    async send(url, options) {
        return new Promise((resolve, reject) => {
            if (!this.channel) {
                reject(new Error('Channel not opened'));
                return;
            }
            if (this.mode === 'production') {
                reject(new Error('Not prepared yet'));
                return;
            }
            const id = crypto.randomUUID();
            pendingRequests[id] = resolve;
            options.inDeveloped = true;
            const opt = {
                type: "fetch-request",
                id: id,
                url,
                server: 'example',
                options: JSON.stringify(options)
            };
            this.channel.postMessage(opt);
        });
    }
    close() {
        this.channel?.close();
        this.channel = undefined;
        return this;
    }
}
let TestUser = class TestUser extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`test-user-102021 input,
test-user-102021 button {
  border: 1px solid #adacac;
  border-radius: 5px;
}
test-user-102021 .container {
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 24px;
}
test-user-102021 .list {
  min-width: 200px;
  border-right: 1px solid #ccc;
  padding-right: 16px;
}
test-user-102021 .list-item {
  padding: 6px;
  cursor: pointer;
}
test-user-102021 .list-item:hover {
  background: #eee;
}
test-user-102021 .delete-btn {
  color: red;
  cursor: pointer;
  margin-left: 8px;
}
test-user-102021 .form {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}
test-user-102021 table {
  width: 100%;
  border-collapse: collapse;
}
test-user-102021 table td,
test-user-102021 table th {
  border: 1px solid #ccc;
  padding: 4px 8px;
}
`);
        this.fire = new Test();
        this.users = [];
        this.audit = [];
        this.iptFilter = '';
        this.form = {
            id: null,
            name: '',
            password: '',
            cpf: ''
        };
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.loadUsers();
        await this.loadAudit();
    }
    // -------------------------------------------------------------
    // 🔹 Render
    // -------------------------------------------------------------
    render() {
        return html `
            <div class="container">

                <!-- LISTA DE USUÁRIOS -->
                <div class="list">
                    <h3>Usuários <input type="text" @input=${(e) => this.iptFilter = e.target.value}/> <button @click=${() => this.loadUsers(this.iptFilter)}> Buscar </button></h3>

                    ${this.users.map(u => html `
                        <div class="list-item" @click=${() => this.selectUser(u)}>
                            ${u.name} (${u.email})
                            <span class="delete-btn" @click=${(e) => {
            e.stopPropagation();
            this.onDelete(u.id);
        }}>🗑</span>
                        </div>
                    `)}
                </div>

                <!-- FORMULÁRIO -->
                <div>
                    <h3>${this.form.id ? "Editar usuário" : "Novo usuário"}</h3>

                    <div class="form">
                        <label>
                            Nome:
                            <input 
                                type="text"
                                .value=${this.form.name}
                                @input=${(e) => this.updateField("name", e.target.value)}
                            >
                        </label>

                        <label>
                            Password:
                            <input 
                                type="text"
                                .value=${this.form.password}
                                @input=${(e) => this.updateField("password", e.target.value)}
                            >
                        </label>

                        <label>
                            Cpf:
                            <input 
                                type="text"
                                .value=${this.form.cpf}
                                @input=${(e) => this.updateField("cpf", e.target.value)}
                            >
                        </label>

                        <button @click=${this.onSave}>
                            Salvar
                        </button>
                        <button @click=${this.resetForm}>Limpar</button>
                    </div>

                    <!-- AUDITORIA -->
                    <h3>Audit Log</h3>
                    <table>
                        <thead>
                            <tr>
                            <th>Id</th>
                                <th>User</th>
                                <th>Data</th>
                                <th>Ação</th>
                                <th>Origem</th>
                                <th>Descrição</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${this.audit.map(a => html `
                                <tr>
                                <td>${a.id}</td> 
                                    <td>${a.user}</td> 
                                    <td>${a.date}</td>
                                    <td>${a.action}</td>
                                    <td>${a.origin}</td>
                                    <td><pre>${a.description}</pre></td>
                                </tr>
                            `)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    // -------------------------------------------------------------
    // 🔹 Você implementa a lógica interna dessas funções no backend
    // -------------------------------------------------------------
    async loadUsers(filter = '') {
        const req = {
            action: 'listUser',
            params: { filter }
        };
        const res = await this.fire.send('example/exec/', req);
        const dt = (await res.json()).data;
        const u = [];
        dt.forEach((i) => {
            u.push({
                id: i.id,
                name: i.details.name,
                password: i.details.password,
                cpf: i.details.cpf,
            });
        });
        this.users = u;
    }
    async saveUser(user) {
        const req = {
            version: '1',
            action: user.id ? 'uppUser' : 'addUser',
            params: {
                id: user.id,
                details: {
                    name: user.name,
                    password: user.password,
                    cpf: user.cpf
                }
            }
        };
        const res = await this.fire.send('example/exec/', req);
        console.info(res);
    }
    async deleteUser(id) {
        // remover no backend
        const req = {
            version: '1',
            action: 'delUser',
            params: {
                id,
            }
        };
        const res = await this.fire.send('example/exec/', req);
        console.info(res);
    }
    async loadAudit() {
        const req = {
            action: 'listAudit',
            param: { filter: '' }
        };
        const res = await this.fire.send('example/exec/', req);
        const dt = (await res.json()).data;
        this.audit = dt;
    }
    // -------------------------------------------------------------
    // 🔹 Lógica de interface
    // -------------------------------------------------------------
    selectUser(u) {
        this.form = {
            id: u.id,
            name: u.name,
            password: u.password,
            cpf: u.cpf
        };
    }
    async onSave() {
        await this.saveUser(this.form);
        await this.loadUsers();
        await this.loadAudit();
        this.resetForm();
    }
    resetForm() {
        this.form = { id: null, name: '', password: '', cpf: '' };
    }
    async onDelete(id) {
        await this.deleteUser(id);
        await this.loadUsers();
        await this.loadAudit();
        if (this.form.id === id) {
            this.resetForm();
        }
    }
    updateField(field, value) {
        this.form = { ...this.form, [field]: value };
    }
};
__decorate([
    state()
], TestUser.prototype, "users", void 0);
__decorate([
    state()
], TestUser.prototype, "audit", void 0);
__decorate([
    state()
], TestUser.prototype, "form", void 0);
TestUser = __decorate([
    customElement('test-user-102021')
], TestUser);
export { TestUser };
