"use strict";
/// <mls shortName="agentEndpointCommonLocal" project="102021" enhancement="_blank" folder="" />
