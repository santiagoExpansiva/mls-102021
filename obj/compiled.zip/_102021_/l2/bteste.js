/// <mls fileReference="_102021_/l2/bteste.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { IAteste } from '/_102021_/l2/ateste.js';
import { customElement } from 'lit/decorators.js';
let Bteste = class Bteste extends IAteste {
};
Bteste = __decorate([
    customElement('bteste-102021')
], Bteste);
export { Bteste };
