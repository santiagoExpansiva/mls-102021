/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbPersistenceTable.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, planTableColumns, createPromptReadyIntent, createUpdateStatusIntent, enqueueNext, extractPlannerOutput, plannerConfig, createPlannerToolSchema, batchSchema, asArray, saveAgentTrace, saveDefs, buildArtifact, buildPipelineItem, persistenceTableFileInfo, domainEntityFileInfo, dtsRef, layerSkills, readString, lowerFirst, logPrefix, } from '/_102021_/l2/agentChangeBackend/cbShared.js';
import { persistenceTableResultSchema } from '/_102021_/l2/agentChangeBackend/cbSchemas.js';
const AGENT_NAME = 'agentCbPersistenceTable';
const TOOL_NAME = 'submitPersistenceTables';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the table definitions.', batchSchema(persistenceTableResultSchema));
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Generate TableDefinition (indexed columns + details JSONB)', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const scan = await readBackendScan(['toCreate', 'inProgress']);
    const entityIds = new Set(scan.entities.map(e => e.entityId));
    const byId = new Map(scan.entities.map(e => [e.entityId, e]));
    const tables = scan.aggregates.map(agg => {
        const plan = planTableColumns(byId.get(agg.rootEntity)?.fields || [], entityIds);
        return { tableId: agg.rootEntity, indexed: plan.indexed, detailsFields: plan.details, childCollections: agg.embeddedMembers };
    });
    // Append-only event tables (telemetry/audit): same JSONB model, plus appendOnly + retentionDays so
    // the TableDefinition gets purpose 'controle' and a TTL (omit retentionDays = permanent, for audit).
    const eventTables = scan.events.filter(ev => ev.persisted).map(ev => {
        const plan = planTableColumns(ev.fields || [], entityIds);
        return { tableId: ev.entityId, indexed: plan.indexed, detailsFields: plan.details, childCollections: [], appendOnly: true, purpose: 'controle', retentionDays: ev.retentionDays };
    });
    const human = `## Tables to derive (indexed columns vs details JSONB)\n${JSON.stringify(tables, null, 2)}\n\n## Append-only event tables\n${JSON.stringify(eventTables, null, 2)}\n\nReturn one TableDefinition per table: snake_case tableName/columns; only indexed columns are real, the rest live in a details JSONB column (detailsColumn.enabled=true, childCollections listed). For event tables echo appendOnly=true, purpose="controle" and retentionDays (omit it for permanent audit); index the owner FK and the ordering timestamp.`;
    return [createPromptReadyIntent(context, parentStep, hookSequential, (step.prompt || ""), systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let trace;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const out = extractPlannerOutput(payload, plannerConfig(TOOL_NAME));
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const module = scan.moduleNames[0] || 'unknown';
        let saved = 0;
        for (const item of asArray(out.result.items)) {
            const tableId = readString(item.tableId);
            if (!tableId)
                continue;
            const fi = persistenceTableFileInfo(module, tableId);
            const dependsFiles = [dtsRef(domainEntityFileInfo(module, tableId))];
            const pipeline = [buildPipelineItem(lowerFirst(tableId), 'persistenceTable', fi, dependsFiles, layerSkills('persistenceTable.md'))];
            await saveDefs(fi, `${lowerFirst(tableId)}TableDefinition`, buildArtifact('table', tableId, module, AGENT_NAME, item), pipeline);
            saved++;
        }
        console.log(`${logPrefix(agent)} saved ${saved} table defs`);
        if (out.status === 'failed') {
            status = 'failed';
            trace = 'model returned failed';
        }
    }
    catch (error) {
        status = 'failed';
        trace = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${trace}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    const intents = [];
    if (status === 'completed')
        intents.push(enqueueNext(context, parentStep, step, 'cb-gen-adapter', 'agentCbRepositoryAdapter', 'Gerar adapters de persistência', {}));
    intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, status, trace, status === 'completed' ? 'input_output' : undefined));
    return intents;
}
const systemPrompt = `
<!-- modelType: codehigh -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} (hexagonal layer_1_external/adapters/persistence). Derive one TableDefinition
per table: snake_case tableName and columns; ONLY indexed fields are real columns (PK, queried FKs,
status, ordering timestamps); everything else + child collections go into a details JSONB column
(detailsColumn.enabled=true). primaryKey + indexes. Call "{{toolName}}"; result.items = array. No prose.
`;
