/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbAggregateIndex.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, createPromptReadyIntent, createUpdateStatusIntent, enqueueNext, extractPlannerOutput, plannerConfig, createPlannerToolSchema, saveAgentTrace, asArray, logPrefix, } from '/_102021_/l2/agentChangeBackend/cbShared.js';
import { aggregateIndexResultSchema } from '/_102021_/l2/agentChangeBackend/cbSchemas.js';
const AGENT_NAME = 'agentCbAggregateIndex';
const TOOL_NAME = 'submitAggregateIndex';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the aggregate index for the module.', aggregateIndexResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Derive aggregate boundaries from kind + relationships', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const scan = await readBackendScan(['toCreate', 'inProgress']);
    const reduced = {
        entities: scan.entities.map(e => ({ entityId: e.entityId, kind: e.kind, ownership: e.ownership })),
        relationships: scan.relationships,
        baselineAggregates: scan.aggregates,
    };
    const human = `## Module(s): ${scan.moduleNames.join(', ')}\n\n## Ontology + relationships (data only)\n${JSON.stringify(reduced, null, 2)}\n\nReturn the refined aggregate index.`;
    return [createPromptReadyIntent(context, parentStep, hookSequential, (step.prompt || ""), systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let trace;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const out = extractPlannerOutput(payload, plannerConfig(TOOL_NAME));
        const aggregates = asArray(out.result.aggregates);
        console.log(`${logPrefix(agent)} aggregates=${aggregates.length}`);
        if (out.status === 'failed') {
            status = 'failed';
            trace = 'model returned failed';
        }
    }
    catch (error) {
        status = 'failed';
        trace = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${trace}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    const intents = [];
    if (status === 'completed')
        intents.push(enqueueNext(context, parentStep, step, 'cb-persistence-index', 'agentCbPersistenceIndex', 'Planejar persistência (JSONB)', {}));
    intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, status, trace, status === 'completed' ? 'input_output' : undefined));
    return intents;
}
const systemPrompt = `
<!-- modelType: codehigh -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} for the collab.codes agentChangeBackend flow (Stage 3, hexagonal backend).
Group the ontology entities into AGGREGATES using kind + relationships:
- kind "core" -> aggregate root (own table).
- kind "supporting" in a oneToMany/oneToOne under a core, not queried on its own -> embeddedMembers of that root (folded into its details JSONB, no own table).
- kind "event" -> events[] (own append-only table).
- kind "mdm" -> mdmRefs[] (NO local table; read via 102034).
Use canonical entityIds only. Call "{{toolName}}" with status/result/questions/trace. No prose.
`;
