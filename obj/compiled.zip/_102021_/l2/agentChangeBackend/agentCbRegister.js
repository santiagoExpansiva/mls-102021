/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbRegister.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNext, createUpdateStatusIntent, logPrefix } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbRegister', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic backend registration (composition root; routes/tables discovered at runtime)', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const moduleTables = scan.aggregates.filter(a => true).map(a => a.rootEntity);
        console.log(`${logPrefix(agent)} runtime-discovered tables=${moduleTables.join(',') || '(none)'} (MDM excluded); routes via controllers' exported routes; composition root port->adapter`);
        return [
            enqueueNext(context, parentStep, step, 'cb-validate-all', 'agentCbValidateAll', 'Validar artefatos l1', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Registered ${moduleTables.length} module table(s).`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
