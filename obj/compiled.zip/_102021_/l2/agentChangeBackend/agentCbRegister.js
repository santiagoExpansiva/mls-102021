/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbRegister.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNext, createUpdateStatusIntent, logPrefix } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbRegister', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic backend registration (manifest, router, composition root)', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const moduleTables = scan.aggregates.filter(a => true).map(a => a.rootEntity);
        console.log(`${logPrefix(agent)} register manifest tables=${moduleTables.join(',') || '(none)'} (MDM excluded), router + port->adapter composition root`);
        return [
            enqueueNext(context, parentStep, step, 'cb-validate-all', 'agentCbValidateAll', 'Validar artefatos l1', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Registered ${moduleTables.length} module table(s).`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
