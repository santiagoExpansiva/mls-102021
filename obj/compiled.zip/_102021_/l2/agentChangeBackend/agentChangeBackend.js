/// <mls fileReference="_102021_/l2/agentChangeBackend/agentChangeBackend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setOwnerStatusBackend, createAddStepIntent, createAgentStepPayload, createUpdateStatusIntent, logPrefix, } from '/_102021_/l2/agentChangeBackend/cbShared.js';
const ALL_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'inProgress', 'done'];
export function createAgent() {
    return {
        agentName: 'agentChangeBackend',
        agentProject: 102021,
        agentFolder: 'agentChangeBackend',
        agentDescription: 'Stage 3 backend reconciler (v1, hexagonal). CLI: /rebuild all | /run | /help.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
/** Parse the user prompt into a CLI command. Lenient: the agent mention is stripped and the keyword
 * is matched anywhere (with or without a leading slash), so small formatting differences still work. */
function parseCommand(raw) {
    let t = String(raw || '').toLowerCase();
    t = t.replace(/@@?[a-z0-9_]*changebackend/g, ' ').trim(); // drop @@changeBackend / @@agentChangeBackend
    if (/\brebuild\b/.test(t))
        return 'rebuild';
    if (/\brun\b/.test(t))
        return 'run';
    return 'help';
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const raw = userPrompt || context.message.content || '';
    const cmd = parseCommand(raw);
    // Diagnostic: confirm what actually arrived and how it was parsed (check the console).
    console.log(`${logPrefix(agent)} entry userPrompt="${userPrompt}" content="${context.message.content}" -> cmd=${cmd}`);
    let human;
    if (cmd === 'rebuild') {
        let reset = 0;
        try {
            const scan = await readBackendScan(ALL_STATUSES);
            for (const owner of scan.owners) {
                if (await setOwnerStatusBackend(owner, 'toCreate'))
                    reset++;
            }
            console.log(`${logPrefix(agent)} /rebuild — reset ${reset} owner(s) -> toCreate`);
        }
        catch (e) {
            console.error(`${logPrefix(agent)} /rebuild reset failed: ${e instanceof Error ? e.message : String(e)}`);
        }
        human = `**/rebuild all** — ${reset} owner(s) reset to \`statusBackend = toCreate\`. Regenerating the whole backend (files are overwritten in place). Acompanhe os steps abaixo.`;
    }
    else if (cmd === 'run') {
        human = `**/run** — generating the backend for pending owners (\`statusBackend = toCreate | inProgress\`). Acompanhe os steps abaixo.`;
    }
    else {
        human = HELP;
    }
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: ECHO_SYSTEM },
                // The human turn IS the final, valid collab-llm envelope; the model just returns it verbatim.
                { type: 'human', content: JSON.stringify({ type: 'result', result: human }) },
            ],
            taskTitle: 'agentChangeBackend',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeBackend', flowName: 'agentChangeBackend', version: '1' },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    const cmd = parseCommand(context.message.content);
    if (cmd === 'help') {
        // CLI help shown by the echo above — finish without starting the flow.
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'help')];
    }
    const scanStep = createAgentStepPayload('cb-scan', 'agentCbScanCreateOwners', 'Scan l4 (statusBackend = toCreate)', { planId: 'cb-scan' }, [], 'sequential', 'waiting_human_input');
    return [createAddStepIntent(context, step, scanStep)];
}
const ECHO_SYSTEM = `
<!-- modelType: codeawsfast -->

The user turn contains a single JSON object (a valid collab-llm result envelope, e.g.
{"type":"result","result":"..."}). Return that JSON object EXACTLY and ONLY it — raw JSON, no code
fences, no extra text, no tool calls.
`;
const HELP = `**agentChangeBackend — CLI**

Usage: \`@@changeBackend <command>\`

Commands:
- \`/rebuild all\` — reset \`statusBackend\` of ALL owners (done / inProgress / …) back to \`toCreate\`, then regenerate the whole backend. Files are **overwritten in place** (no manual delete needed).
- \`/run\` — generate for pending owners (\`statusBackend = toCreate | inProgress\`) **without** resetting.
- \`/help\` — show this help.

Anything else shows this help.`;
