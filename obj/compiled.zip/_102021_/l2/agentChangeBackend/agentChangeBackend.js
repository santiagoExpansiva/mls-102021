/// <mls fileReference="_102021_/l2/agentChangeBackend/agentChangeBackend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAddStepIntent, createAgentStepPayload } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return {
        agentName: 'agentChangeBackend',
        agentProject: 102021,
        agentFolder: 'agentChangeBackend',
        agentDescription: 'Stage 3 backend reconciler (v1 autonomous, create-only). Scans l4 statusBackend and generates the 3-layer hexagonal backend.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: userPrompt || 'Run agentChangeBackend v1 autonomous scan.' },
            ],
            taskTitle: 'agentChangeBackend',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeBackend', flowName: 'agentChangeBackend', version: '1' },
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    const scanStep = createAgentStepPayload('cb-scan', 'agentCbScanCreateOwners', 'Scan l4 (statusBackend = toCreate)', {}, [], 'sequential', 'waiting_human_input');
    return [createAddStepIntent(context, step, scanStep)];
}
const systemPrompt = `
<!-- modelType: codeawsfast -->

Return only:
{ "type": "result", "result": "ok" }

This root agent ignores the model result. It only starts the deterministic l4 statusBackend scan.
`;
