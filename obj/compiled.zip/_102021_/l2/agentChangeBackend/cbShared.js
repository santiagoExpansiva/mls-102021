/// <mls fileReference="_102021_/l2/agentChangeBackend/cbShared.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, } from '/_102020_/l2/agentNewSolution2/ns2Extract.js';
import { saveAgentTrace } from '/_102020_/l2/agentNewSolution2/ns2Artifacts.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, saveAgentTrace, };
/** Loose planner config: validates the envelope and returns the `result` object as a record. Each
 * agent reads the array property it expects (items/aggregates/tables/...). */
export function plannerConfig(toolName) {
    return { toolName, normalizeResult: (value) => assertRecord(value, 'result') };
}
/** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
 * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
export function batchSchema(itemSchema) {
    return { type: 'object', additionalProperties: false, required: ['items'], properties: { items: { type: 'array', items: itemSchema } } };
}
export function asArray(value) {
    return Array.isArray(value) ? value.filter(isRecord) : [];
}
// ── deterministic l4 scan ──────────────────────────────────────────────────────
export async function readBackendScan(statuses = ['toCreate']) {
    const wanted = new Set(statuses);
    const project = mls.actualProject || 0;
    const moduleNames = new Set();
    const entityToModule = new Map();
    const entities = [];
    const relationships = [];
    const rawOwners = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        const shortName = String(file.shortName || '');
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!isRecord(parsed))
            continue;
        if (folder === 'operations')
            rawOwners.push({ kind: 'operation', obj: parsed });
        else if (folder === 'workflows')
            rawOwners.push({ kind: 'workflow', obj: parsed });
        else if (shortName === 'module' && folder && !folder.includes('/')) {
            const moduleName = readString((isRecord(parsed.module) ? parsed.module : parsed).moduleName) || folder;
            moduleNames.add(moduleName);
            collectModuleOntology(parsed, moduleName, entities, entityToModule, relationships);
        }
        else if (folder.endsWith('/ontology')) {
            const moduleName = folder.split('/')[0];
            const entityId = readString(parsed.entityId) || shortName;
            if (moduleName && entityId) {
                moduleNames.add(moduleName);
                entityToModule.set(entityId, moduleName);
                upsertEntity(entities, {
                    entityId,
                    title: readString(parsed.title) || entityId,
                    kind: readString(parsed.kind) || 'core',
                    ownership: readString(parsed.ownership) || 'moduleOwned',
                    moduleName,
                    fields: Array.isArray(parsed.fields) ? parsed.fields.filter(isRecord) : undefined,
                });
            }
        }
    }
    const moduleFallback = moduleNames.size === 1 ? Array.from(moduleNames)[0] : 'unknown';
    const owners = rawOwners
        .map(({ kind, obj }) => ownerFrom(kind, obj, entityToModule, moduleFallback))
        .filter((o) => !!o && wanted.has(o.statusBackend));
    const aggregates = deriveAggregates(entities, relationships);
    return { project, moduleNames: Array.from(moduleNames).sort(), owners, entities, relationships, aggregates };
}
function collectModuleOntology(moduleDefs, moduleName, entities, entityToModule, relationships) {
    const ontology = isRecord(moduleDefs.ontology) ? moduleDefs.ontology : undefined;
    const ents = ontology && isRecord(ontology.entities) ? ontology.entities : undefined;
    if (ents) {
        for (const [entityId, raw] of Object.entries(ents)) {
            if (!isRecord(raw))
                continue;
            entityToModule.set(entityId, moduleName);
            upsertEntity(entities, {
                entityId,
                title: readString(raw.title) || entityId,
                kind: readString(raw.kind) || 'core',
                ownership: readString(raw.ownership) || 'moduleOwned',
                moduleName,
            });
        }
    }
    const rels = Array.isArray(moduleDefs.relationships) ? moduleDefs.relationships : [];
    for (const rel of rels) {
        if (!isRecord(rel))
            continue;
        const fromEntity = readString(rel.fromEntity);
        const toEntity = readString(rel.toEntity);
        if (fromEntity && toEntity)
            relationships.push({ fromEntity, toEntity, type: readString(rel.type) || 'manyToOne' });
    }
}
function ownerFrom(kind, obj, entityToModule, fallbackModule) {
    const id = readString(obj.operationId) || readString(obj.workflowId);
    if (!id)
        return null;
    const entity = readString(obj.entity);
    const reads = readStringArray(obj.reads);
    const writes = readStringArray(obj.writes);
    const moduleName = entityToModule.get(entity) || entityToModule.get(reads[0]) || entityToModule.get(writes[0]) || fallbackModule;
    return {
        kind,
        id,
        title: readString(obj.title) || id,
        entity,
        reads,
        writes,
        rulesApplied: readStringArray(obj.rulesApplied),
        statusBackend: readString(obj.statusBackend) || '',
        moduleName,
    };
}
// ── aggregate derivation (baseline; the LLM index agent may refine) ────────────
export function deriveAggregates(entities, relationships) {
    const byId = new Map(entities.map(e => [e.entityId, e]));
    const cores = entities.filter(e => e.kind === 'core');
    const aggregates = [];
    for (const core of cores) {
        const embeddedMembers = [];
        const events = [];
        const mdmRefs = [];
        for (const rel of relationships) {
            // a supporting child related to this core (root -> child) folds into the root details JSONB
            const childId = rel.fromEntity === core.entityId ? rel.toEntity : rel.toEntity === core.entityId ? rel.fromEntity : '';
            if (!childId)
                continue;
            const child = byId.get(childId);
            if (!child)
                continue;
            if (child.kind === 'supporting' && (rel.type === 'oneToMany' || rel.type === 'oneToOne'))
                push(embeddedMembers, childId);
            else if (child.kind === 'event')
                push(events, childId);
            else if (child.kind === 'mdm')
                push(mdmRefs, childId);
        }
        aggregates.push({ aggregateId: core.entityId, rootEntity: core.entityId, embeddedMembers, events, mdmRefs });
    }
    return aggregates;
}
/** Heuristic: a field needs a real column when it is the id (PK), a reference/FK (type is an entity
 * id or ends with "Id"), a status/lifecycle field, or an ordering timestamp (createdAt). Everything
 * else goes into details JSONB. Deterministic baseline for the LLM persistence-index agent. */
export function planTableColumns(fields, knownEntityIds) {
    const indexed = [];
    const details = [];
    for (const f of fields) {
        const fieldId = readString(f.fieldId);
        if (!fieldId)
            continue;
        const type = readString(f.type);
        const isId = fieldId === 'id' || /Id$/.test(fieldId);
        const isRef = knownEntityIds.has(type);
        const isStatus = fieldId === 'status' || Array.isArray(f.enum);
        const isOrderTs = fieldId === 'createdAt';
        if (isId || isRef || isStatus || isOrderTs) {
            indexed.push({ fieldId, reason: isId ? 'pk/fk' : isRef ? 'fk' : isStatus ? 'status' : 'ordering' });
        }
        else {
            details.push(fieldId);
        }
    }
    return { indexed, details };
}
// ── l1 hexagonal file-info builders ────────────────────────────────────────────
const L1 = 1;
function defs(folder, shortName) {
    return { project: mls.actualProject || 0, level: L1, folder, shortName: toSafeShortName(shortName), extension: '.defs.ts' };
}
export function domainEntityFileInfo(m, entityId) { return defs(`${m}/layer_3_domain/entities`, lowerFirst(entityId)); }
export function valueObjectFileInfo(m, memberId) { return defs(`${m}/layer_3_domain/value-objects`, lowerFirst(memberId)); }
export function repositoryPortFileInfo(m, entityId) { return defs(`${m}/layer_2_application/ports`, `${lowerFirst(entityId)}Repository`); }
export function usecaseFileInfo(m, usecaseId) { return defs(`${m}/layer_2_application/usecases`, lowerFirst(usecaseId)); }
export function persistenceTableFileInfo(m, tableId) { return defs(`${m}/layer_1_external/adapters/persistence`, lowerFirst(tableId)); }
export function repositoryAdapterFileInfo(m, entityId) { return defs(`${m}/layer_1_external/adapters/persistence`, `${lowerFirst(entityId)}RepositoryAdapter`); }
export function httpControllerFileInfo(m, pageId) { return defs(`${m}/layer_1_external/adapters/http/controllers`, lowerFirst(pageId)); }
// ── defs writer (main export + pipeline export, self-sufficient) ───────────────
export function defsRef(fileInfo) {
    return `_${fileInfo.project}_/l${fileInfo.level}/${fileInfo.folder}/${fileInfo.shortName}.defs.ts`;
}
/** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
export function dtsRef(fileInfo) {
    return defsRef(fileInfo).replace(/\.defs\.ts$/, '.d.ts');
}
/** Standard planning envelope shared by every .defs.ts data block. */
export function buildArtifact(artifactType, artifactId, moduleName, agentName, data) {
    return { schemaVersion: '2026-06-26', artifactType, artifactId, moduleName, status: 'draft', source: { agentName, stepId: 0, planId: '' }, data };
}
/** Best-effort layer skill ref for the materialization context (reused 4-layer skills until the
 * hexagonal skills are authored). Always paired with the platform defs. */
export function layerSkills(skillFile) {
    return [`_102021_/l2/skills/${skillFile}`, '_102034_.d.ts'];
}
/** Build the pipeline item that makes a .defs.ts self-sufficient for agentMaterializeGen: it carries
 * the outputPath (.ts), the dependsFiles (.d.ts of the inner callee layer) and skills (the LLM
 * context = layer skill + platform defs). See spec.md (auto-suficiência). */
export function buildPipelineItem(shortName, type, fileInfo, dependsFiles, skills, opts = {}) {
    const defPath = defsRef(fileInfo);
    return {
        id: `${shortName}__${type}`,
        type,
        outputPath: defPath.replace(/\.defs\.ts$/, '.ts'),
        defPath,
        dependsFiles,
        dependsOn: [],
        skills,
        ...(opts.rulesPath ? { rulesPath: opts.rulesPath } : {}),
        ...(opts.rulesApplied && opts.rulesApplied.length ? { rulesApplied: opts.rulesApplied } : {}),
        ...(opts.afterSaveBackEnd ? { afterSaveBackEnd: opts.afterSaveBackEnd } : {}),
        agent: 'agentMaterializeGen',
    };
}
/** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
 * (optionally) the `export const pipeline`. Force-overwrites. */
export async function saveDefs(fileInfo, exportName, data, pipeline) {
    const ref = defsRef(fileInfo);
    let src = `/// <mls fileReference="${ref}" enhancement="_blank"/>\n\n`;
    src += `export const ${exportName} = ${JSON.stringify(data, null, 2)} as const;\n\nexport default ${exportName};\n`;
    if (pipeline && pipeline.length)
        src += `\nexport const pipeline = ${JSON.stringify(pipeline, null, 2)} as const;\n`;
    const info = mls.stor.convertFileReferenceToFile(ref);
    const param = { ...info, source: src };
    const file = await createStorFile(param, true, true, true);
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: src });
    return ref;
}
// ── statusBackend mutation (deterministic) ─────────────────────────────────────
/** Read the owner's l4 .defs.ts, set statusBackend, and rewrite it preserving the export name. */
export async function setOwnerStatusBackend(owner, status) {
    const folder = owner.kind === 'operation' ? 'operations' : 'workflows';
    const project = mls.actualProject || 0;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || String(file.folder || '') !== folder)
            continue;
        const content = String(await file.getContent());
        const parsed = parseDefsSource(content);
        const idField = owner.kind === 'operation' ? 'operationId' : 'workflowId';
        if (!isRecord(parsed) || readString(parsed[idField]) !== owner.id)
            continue;
        const exportName = readExportName(content);
        if (!exportName)
            return false;
        parsed.statusBackend = status;
        await saveDefs({ project, level: 4, folder, shortName: String(file.shortName || toSafeShortName(owner.id)), extension: '.defs.ts' }, exportName, parsed);
        return true;
    }
    return false;
}
// ── intent / step helpers (mirrored, self-contained) ───────────────────────────
export function createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
    if (cleaner)
        intent.cleaner = cleaner;
    return intent;
}
export function createAgentStepPayload(planId, agentName, stepTitle, args, dependsOn, executionMode, status = 'waiting_dependency', dynamicSource) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        agentName,
        prompt: typeof args === 'string' ? args : JSON.stringify(args ?? {}),
        rags: [],
        planning: { planId, dependsOn, executionMode, executionHost: 'client', ...(dynamicSource ? { dynamicSource } : {}) },
    };
}
export function createAddStepIntent(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
export function createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, toolSchema, toolName) {
    if (!context.task)
        throw new Error('[createPromptReadyIntent] task invalid');
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: toolName } },
    };
}
/** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
export function createParallelStepIntent(context, parentStep, planId, agentName, stepTitle, args, dependsOn = [], maxParallel = 5) {
    const step = createAgentStepPayload(planId, agentName, stepTitle, {}, dependsOn, 'parallel_dynamic', 'in_progress');
    step.interaction = {
        input: [{ type: 'system', content: '<!-- modelType: codepro -->' }],
        cost: 0,
        trace: [`queued ${args.length} parallel args for ${agentName}`],
        payload: null,
    };
    return { ...createAddStepIntent(context, parentStep, step), executionMode: { type: 'parallel', args, maxParallel } };
}
export function logPrefix(agent) {
    return `[${agent.agentName} v1]`;
}
export function planIdOf(step) {
    return step?.planning?.planId || '';
}
/** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
 * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
 * compile; parallelization is a later optimization. */
export function enqueueNext(context, parentStep, currentStep, planId, agentName, stepTitle, args = {}) {
    const dep = planIdOf(currentStep);
    // Unique args per step (embed planId) AND nest under the current step, so the runtime's hook
    // dispatch key (parentStepId, args) never collides — every chained step lives under a distinct
    // parent with a distinct prompt. (Mirrors agentPrepareDefsL1's per-child unique selector args.)
    const mergedArgs = { planId, ...(args && typeof args === 'object' ? args : {}) };
    const next = createAgentStepPayload(planId, agentName, stepTitle, mergedArgs, dep ? [dep] : [], 'sequential', 'waiting_dependency');
    return createAddStepIntent(context, currentStep, next);
}
// ── small parsers ──────────────────────────────────────────────────────────────
export function parseDefsSource(content) {
    const start = content.indexOf('= ');
    const end = content.lastIndexOf(' as const;');
    if (start === -1 || end === -1 || end <= start)
        return null;
    try {
        return JSON.parse(content.slice(start + 2, end));
    }
    catch {
        return null;
    }
}
function readExportName(content) {
    const m = content.match(/export const\s+([A-Za-z0-9_$]+)\s*=/);
    return m ? m[1] : '';
}
export function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
export function readStringArray(value) {
    return Array.isArray(value) ? value.map(readString).filter(Boolean) : [];
}
export function lowerFirst(value) {
    return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
}
export function capitalize(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}
export function toSafeShortName(value) {
    return (value || '').trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'artifact';
}
function push(list, value) {
    if (value && !list.includes(value))
        list.push(value);
}
function upsertEntity(entities, entity) {
    const existing = entities.find(e => e.entityId === entity.entityId);
    if (existing)
        Object.assign(existing, entity);
    else
        entities.push(entity);
}
