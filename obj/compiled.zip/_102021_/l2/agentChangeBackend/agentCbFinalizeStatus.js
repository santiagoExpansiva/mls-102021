/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbFinalizeStatus.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setOwnerStatusBackend, enqueueNext, createUpdateStatusIntent } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbFinalizeStatus', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic statusBackend inProgress -> done', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['inProgress']);
        let done = 0;
        for (const owner of scan.owners) {
            if (await setOwnerStatusBackend(owner, 'done'))
                done++;
        }
        return [
            enqueueNext(context, parentStep, step, 'cb-final-summary', 'agentCbFinalSummary', 'Resumo do run', { ownersDone: done }),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Marked ${done} owner(s) done.`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
