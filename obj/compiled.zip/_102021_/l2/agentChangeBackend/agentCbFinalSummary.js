/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbFinalSummary.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, isRecord, parseMaybeJson, logPrefix } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbFinalSummary', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Terminal run summary + task completion', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const args = isRecord(parseMaybeJson(step.prompt)) ? parseMaybeJson(step.prompt) : {};
    const summary = args.noWork ? 'agentChangeBackend: nothing to create (no statusBackend = toCreate).' : `agentChangeBackend: run complete. owners done = ${args.ownersDone ?? 0}.`;
    console.log(`${logPrefix(agent)} ${summary}`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary)];
}
