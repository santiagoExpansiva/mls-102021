/// <mls fileReference="_102021_/l2/testeAgent.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { addOrUpdateEndPoint } from '/_102021_/l2/aiIntegrationHub.js';
let ExampleCqrs = class ExampleCqrs extends StateLitElement {
    render() {
        return html `<button @click=${this.clickMsg}>fire</button>`;
    }
    clickMsg() {
        const pt1 = {
            name: "listServices",
            intent: "I need an endpoint to fetch available services for selection.",
            responseInterfaces: "interface Service {\nid: string;\nname: string;\ndescription: string;\nprice: string;\niconUrl: string;\n}\ninterface ServicesResponse {\nservices: Service[];\n}",
            requestInterfaces: "",
        };
        const pt2 = {
            name: "listHighlightedServices",
            intent: "I need an endpoint to fetch the list of highlighted services.",
            responseInterfaces: "interface Service {\nname: string;\ndescription: string;\niconUrl: string;\n}\ninterface ServicesResponse {\nservices: Service[];\n}",
            requestInterfaces: "",
        };
        this.addMessageIA(JSON.stringify(pt1), pt1);
    }
    async addMessageIA(prompt, pt1) {
        //await executeAgentByFile('agentEndpoint', prompt, mls.stor.files['102021_2_testAgent.ts'], false);
        console.info('iniciou');
        await addOrUpdateEndPoint(pt1.name, pt1.intent, pt1.responseInterfaces, pt1.requestInterfaces, undefined);
        console.info('terminou');
    }
};
ExampleCqrs = __decorate([
    customElement('teste-agent-102021')
], ExampleCqrs);
export { ExampleCqrs };
