/// <mls shortName="module" project="102021" enhancement="_blank" folder="example" />
export const integrations = [];
export const tests = [];
