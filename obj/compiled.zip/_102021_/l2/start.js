/// <mls fileReference="_102021_/l2/start.ts" enhancement="_blank" />
import { getProjectConfig } from '/_100554_/l2/libCommom.js';
import { build, loadEsbuild } from '/_102021_/l2/buildServer.js';
let iframes = {};
export let servers = {};
export let listItens = [];
let div = document.createElement('div');
let body = document.querySelector('body');
let channel = new BroadcastChannel('collab');
export async function start(project, startServers = 'none') {
    if (listItens.length > 0)
        return;
    await loadEsbuild();
    const m = await getProjectConfig(project);
    const array = [];
    if (!m)
        throw new Error('[start]: Not found project module');
    if (m.modules) {
        m.modules.forEach((s, index) => {
            if (!s.pathServer)
                return;
            array.push({
                name: s.name || 'S' + (index + 1),
                server: s.pathServer || 'null',
                icon: s.icon
            });
        });
    }
    listItens = array;
    div.style.display = 'none';
    body.appendChild(div);
    loadIframes(startServers);
}
async function loadIframes(startServers) {
    for await (let info of listItens) {
        createServer(info, startServers === 'all' || startServers === info.name);
    }
}
function createServer(info, start) {
    if (iframes[info.server])
        return;
    const server = {
        icon: info.icon,
        name: info.name,
        server: info.server,
        iframe: document.createElement('iframe'),
        status: 'off'
    };
    server.iframe.src = '/_100554_servicePreviewL1';
    server.iframe.onload = () => {
        try {
            setHtml(server);
            if (start) {
                server.status = 'on';
                onServer(server);
            }
        }
        catch (e) {
            server.status = 'off';
        }
    };
    server.iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
    iframes[info.server] = server;
    servers = {};
    Object.keys(iframes).forEach((key) => {
        const f = listItens.find((i) => i.server === key);
        if (f)
            servers[f.name] = iframes[key];
    });
    top.previewL1 = servers;
    div.appendChild(server.iframe);
}
export async function setHtml(server) {
    if (!server.iframe.contentDocument)
        return;
    const path = mls.l2.getPath(server.server);
    let txt = `
    <collab-console-l1-100554 file="${server.server}"></collab-console-l1-100554>
    <style>
        html{
            height:100%;
        }
        body{
            height: calc(100% - 34px);
        }
    </style>`;
    server.iframe.contentDocument.body.innerHTML = txt;
    const info = {
        project: path.project,
        shortName: path.shortName,
        folder: path.folder,
    };
    const bundle = await build(info);
    mountJSImporMap(server.iframe);
    mountJSBundle(bundle, server.iframe);
}
function mountJSImporMap(ifr) {
    try {
        if (!ifr.contentDocument)
            return;
        const importsMap = [
            '"lit": "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js"',
            '"lit/decorators.js": "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm"'
        ];
        const js = '{"imports": { ' + importsMap.join(',\n') + '} }';
        const script = document.createElement('script');
        script.type = 'importmap';
        script.textContent = js;
        ifr.contentDocument.head.appendChild(script);
    }
    catch (e) {
        console.info('Error mountJSImporMap: ' + e.message);
        return;
    }
}
function mountJSBundle(jsCode, ifr) {
    try {
        if (!ifr.contentDocument)
            return;
        const script = document.createElement('script');
        script.type = "module";
        script.textContent = jsCode;
        ifr.contentDocument.body.appendChild(script);
        const scriptBase = document.createElement('script');
        scriptBase.type = "module";
        scriptBase.src = "/_100554_collabConsoleL1";
        ifr.contentDocument.body.appendChild(scriptBase);
    }
    catch (e) {
        console.info('Error mountJSBundle: ' + e.message);
    }
}
export function onServer(server) {
    if (!server.iframe.contentWindow)
        return;
    channel.onmessage = async (event) => {
        const ev = event.data;
        if (ev.server !== server.name || ev.type !== "fetch-request")
            return;
        const res = {
            type: "fetch-response",
            id: ev.id,
            body: '',
            status: 200,
            headers: { "Content-Type": "application/json" }
        };
        const method = 'exec';
        if (server.iframe && server.iframe.contentWindow[method]) {
            const exec = server.iframe.contentWindow[method];
            const strJson = ev.options ? ev.options : '{}';
            const resposta = await exec(JSON.parse(strJson));
            res.body = JSON.stringify(resposta);
            channel.postMessage(res);
        }
    };
    /*server.iframe.contentWindow.onmessage = async (e) => {

        const data = e.data;
        console.info('message', data);
        const res: ResponseMsgBase = {
            type: "fetch-response",
            id: data.id,
            body: '',
            status: 200,
            headers: { "Content-Type": "application/json" }
        }

        if (data.type === "fetch-request") {

            const method = 'exec'; // data.url.split('/').filter(Boolean).join('_');
            if (server.iframe && (server.iframe.contentWindow as any)[method]) {

                const exec = (server.iframe.contentWindow as any)[method];
                const strJson = data.options && data.options.body ? data.options.body : '{}';
                const resposta = await exec(JSON.parse(strJson));
                res.body = JSON.stringify(resposta)

                if (window.preview.iframe && window.preview.iframe.contentWindow)
                    window.preview.iframe.contentWindow.postMessage(res, "*" as any);

            }
        }

    };*/
}
export function restartServer(server) {
    const item = listItens.find((i, index) => i.server === server.server);
    if (iframes[server.server]) {
        iframes[server.server].iframe.remove();
        delete iframes[server.server];
    }
    if (item)
        createServer(item, true);
}
export function offServer(server) {
    if (!iframes[server.server])
        return;
    const i = iframes[server.server].iframe;
    if (!i.contentWindow)
        return;
    i.contentWindow.onmessage = () => undefined;
}
