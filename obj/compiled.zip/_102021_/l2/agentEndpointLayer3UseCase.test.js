/// <mls fileReference="_102021_/l2/agentEndpointLayer3UseCase.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
