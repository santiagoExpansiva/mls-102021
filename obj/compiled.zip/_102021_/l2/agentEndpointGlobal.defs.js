"use strict";
/// <mls shortName="agentEndpointGlobal" project="102021" enhancement="_blank" folder="" />
