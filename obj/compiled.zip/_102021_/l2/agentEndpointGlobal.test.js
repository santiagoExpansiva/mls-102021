/// <mls fileReference="_102021_/l2/agentEndpointGlobal.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
