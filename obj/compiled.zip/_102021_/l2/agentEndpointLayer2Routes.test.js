/// <mls fileReference="_102021_/l2/agentEndpointLayer2Routes.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
