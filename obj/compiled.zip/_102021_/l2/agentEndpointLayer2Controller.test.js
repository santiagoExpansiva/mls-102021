/// <mls fileReference="_102021_/l2/agentEndpointLayer2Controller.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
