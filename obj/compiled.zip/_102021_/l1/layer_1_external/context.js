/// <mls fileReference="_102021_/l1/layer_1_external/context.ts" enhancement="_blank" />
import { userDynamoDB } from "./dynamoDB/user.js";
import { userLocalDB } from "./localDB/user.js";
import { auditLocalDB } from "./localDB/audit.js";
export function createContext(param) {
    if (!param.inDeveloped)
        throw new Error('Not implement api production');
    const ctx = {
        io: {
            local: {
                user: userLocalDB,
                audit: auditLocalDB
            },
            dynamoDb: {
                user: userDynamoDB
            }
        }
    };
    return ctx;
}
