/// <mls fileReference="_102021_/l1/layer_1_external/dynamoDB/user.ts" enhancement="_blank" />
class User {
    //-----------METHODS-----------
    async upd(param) {
        return await this.saveUserIndexRecord(param);
    }
    async add(param) {
        return await this.saveUserIndexRecord(param);
    }
    async del(id) {
        return await this.deleteUserIndexRecord(id);
    }
    async list(param) {
        return await this.getAllUserIndexRecord(param);
    }
    //-----------IMPLEMENTS------------
    getTable() {
        return window.table && window.table.usersDynamo ? window.table.usersDynamo : [];
    }
    setTable(array) {
        if (window.table)
            window.table.usersDynamo = array;
        else
            window.table = { usersDynamo: array };
    }
    async saveUserIndexRecord(data) {
        const store = this.getTable();
        return new Promise((resolve, reject) => {
            if (!data.id) {
                data.id = this.getNextId(store);
                store.push(data);
            }
            else {
                const index = store.findIndex((i) => i.id === data.id);
                if (store[index])
                    store[index] = data;
                else
                    store.push(data);
            }
            this.setTable(store);
            resolve(data);
        });
    }
    async getAllUserIndexRecord(param) {
        const store = this.getTable();
        const ret = [];
        store.forEach((s) => {
            if (s.fullText.toLocaleLowerCase().indexOf(param.toLocaleLowerCase()) >= 0)
                ret.push(s);
        });
        return new Promise((resolve, reject) => { resolve(ret); });
    }
    async deleteUserIndexRecord(id) {
        const store = this.getTable();
        const index = store.findIndex((i) => i.id === id);
        if (store[index])
            store.splice(index, 1);
        this.setTable(store);
        return new Promise((resolve, reject) => { resolve(true); });
    }
    getNextId(arr) {
        if (!arr || arr.length === 0)
            return 1; // se o array estiver vazio, começa do 1
        const lastId = Math.max(...arr.map(item => item.id || 0));
        return lastId + 1;
    }
}
export const userDynamoDB = new User();
