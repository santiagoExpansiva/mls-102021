/// <mls fileReference="_102021_/l1/layer_1_external/localDB/user.ts" enhancement="_blank" />
class User {
    //-----------METHODS-----------
    async upd(param) {
        return await this.saveUserRecord(param);
    }
    async add(param) {
        return await this.saveUserRecord(param);
    }
    async del(id) {
        return await this.deleteUserRecord(id);
    }
    async list() {
        return await this.getAllUserRecord();
    }
    //-----------IMPLEMENTS------------
    getTable() {
        return window.table && window.table.users ? window.table.users : [];
    }
    setTable(array) {
        if (window.table)
            window.table.users = array;
        else
            window.table = { users: array };
    }
    async saveUserRecord(data) {
        const store = this.getTable();
        data.version = Date.now().toString();
        return new Promise((resolve, reject) => {
            if (!data.id) {
                data.id = this.getNextId(store);
                store.push(data);
            }
            else {
                const index = store.findIndex((i) => i.id === data.id);
                if (store[index])
                    store[index] = data;
            }
            this.setTable(store);
            resolve(data);
        });
    }
    async getAllUserRecord() {
        const store = this.getTable();
        return new Promise((resolve, reject) => { resolve(store); });
    }
    async deleteUserRecord(id) {
        const store = this.getTable();
        const index = store.findIndex((i) => i.id === id);
        if (store[index])
            store.splice(index, 1);
        this.setTable(store);
        return new Promise((resolve, reject) => { resolve(true); });
    }
    getNextId(arr) {
        if (!arr || arr.length === 0)
            return 1; // se o array estiver vazio, começa do 1
        const lastId = Math.max(...arr.map(item => item.id || 0));
        return lastId + 1;
    }
}
export const userLocalDB = new User();
