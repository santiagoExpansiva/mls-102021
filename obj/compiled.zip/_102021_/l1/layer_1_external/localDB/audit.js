/// <mls fileReference="_102021_/l1/layer_1_external/localDB/audit.ts" enhancement="_blank" />
class Audit {
    //-----------METHODS-----------
    async add(param) {
        return await this.saveAuditRecord(param);
    }
    async list() {
        return await this.getAllAuditRecord();
    }
    //-----------IMPLEMENTS------------
    getTable() {
        return window.table && window.table.audit ? window.table.audit : [];
    }
    setTable(array) {
        if (window.table)
            window.table.audit = array;
        else
            window.table = { audit: array };
    }
    async saveAuditRecord(data) {
        const store = this.getTable();
        data.id = this.getNextId(store);
        return new Promise((resolve, reject) => {
            store.push(data);
            this.setTable(store);
            resolve(data);
        });
    }
    async getAllAuditRecord() {
        const store = this.getTable();
        return new Promise((resolve, reject) => { resolve(store); });
    }
    getNextId(arr) {
        if (!arr || arr.length === 0)
            return 1; // se o array estiver vazio, começa do 1
        const lastId = Math.max(...arr.map(item => item.id || 0));
        return lastId + 1;
    }
}
export const auditLocalDB = new Audit();
