/// <mls fileReference="_102021_/l1/layer_2_controllers/listAudit.ts" enhancement="_blank" />
import * as layer3 from "../layer_3_use_cases/listAudit.js";
export async function listAudit(ctx, data) {
    const ret = {
        statusCode: 200,
        ok: true,
        data: undefined,
        error: undefined
    };
    try {
        ret.data = await layer3.listAudit(ctx);
        return ret;
    }
    catch (e) {
        ret.ok = false;
        ret.statusCode = 500;
        ret.error = e.message;
        return ret;
    }
}
