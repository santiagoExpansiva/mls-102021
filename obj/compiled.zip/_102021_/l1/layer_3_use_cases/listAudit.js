/// <mls fileReference="_102021_/l1/layer_3_use_cases/listAudit.ts" enhancement="_blank" />
export async function listAudit(ctx) {
    return await ctx.io.local.audit.list();
}
