/// <mls fileReference="_102021_/l1/layer_3_use_cases/delUser.ts" enhancement="_blank" />
export async function delUser(ctx, id) {
    const result = await ctx.io.local.user.del(id);
    const audit = {
        user: "system",
        date: new Date().toISOString(),
        action: "delete",
        origin: "User",
        description: result
            ? `User deleted: ${id}`
            : `Attempt to delete user: ${id}`
    };
    ctx.io.local.audit.add(audit);
    return result;
}
