/// <mls fileReference="_102021_/l1/layer_3_use_cases/uppUser.ts" enhancement="_blank" />
export async function uppUser(ctx, data) {
    const list = await ctx.io.local.user.list();
    const before = list.find((f) => f.id === data.id);
    const updated = await ctx.io.local.user.upd(data);
    let changes = {};
    if (before) {
        const oldDetails = before.details || {};
        const newDetails = data.details || {};
        for (const key of Object.keys(newDetails)) {
            if (oldDetails[key] !== newDetails[key]) {
                changes[key] = oldDetails[key];
            }
        }
    }
    const description = before
        ? `Updated user ${data.id}.: ${JSON.stringify(changes)}`
        : `Attempt to update user ${data.id}, but there was no previous record.`;
    const audit = {
        user: "system",
        date: new Date().toISOString(),
        action: "update",
        origin: "User",
        description
    };
    ctx.io.local.audit.add(audit);
    return updated;
}
